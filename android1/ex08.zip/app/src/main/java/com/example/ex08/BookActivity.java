package com.example.ex08;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.SearchView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class BookActivity extends AppCompatActivity {
    String url="https://openapi.naver.com/v1/search/book.json";
    String query="뽀로로";
    JSONArray array=new JSONArray();
    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setTitle("도서검색");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_book);

        list=findViewById(R.id.list);
        new NaverThread().execute();
    }

    class NaverThread extends AsyncTask<String,String,String>{

        @Override
        protected String doInBackground(String... strings) {
            String result=NaverAPI.search(query, url);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            try{
                array = new JSONObject(s).getJSONArray("items");
                BookAdapter bookAdapter=new BookAdapter();
                list.setAdapter(bookAdapter);
            }catch (Exception e){
                System.out.println("오류" + e.toString());
            }
            super.onPostExecute(s);
        }
    }

    class BookAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return array.length();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }


        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view=getLayoutInflater().inflate(R.layout.item,parent,false);
            RatingBar rating=view.findViewById(R.id.rating);
            rating.setVisibility(View.INVISIBLE);

            try {
                JSONObject obj=(JSONObject)array.get(position);
                String strTitle=obj.getString("title");
                String strActor=obj.getString("actor");
                String strImage=obj.getString("image");
                String strRating=obj.getString("userRating");
                float fltRating=Float.parseFloat(strRating);
                String strDirector=obj.getString("director");

                TextView title=view.findViewById(R.id.title);
                title.setText(Html.fromHtml(strTitle));

                TextView actor=view.findViewById(R.id.actor);
                actor.setText(Html.fromHtml(strActor));

                TextView director=view.findViewById(R.id.director);
                director.setText(Html.fromHtml(strDirector));

                rating=view.findViewById(R.id.rating);
                rating.setRating(fltRating);
                ImageView image=view.findViewById(R.id.image);

                System.out.println(".............." + strImage);

                if(!strImage.equals("")){
                    Picasso.with(BookActivity.this)
                            .load(strImage)
                            .into(image);
                }

                final String strLink=obj.getString("link");
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent=new Intent(BookActivity.this,LinkActivity.class);
                        intent.putExtra("link", strLink);
                        startActivity(intent);
                    }
                });

            } catch (JSONException e) {
                System.out.println("오류:" + e.toString());
            }

            return view;
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);

        MenuItem search=menu.findItem(R.id.search);
        SearchView searchView=(SearchView)search.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                query=newText;
                new NaverThread().execute();
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }
}