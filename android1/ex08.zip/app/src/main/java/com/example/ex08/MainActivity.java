package com.example.ex08;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.le.AdvertisingSetParameters;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.SearchView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    JSONArray array=new JSONArray();
    Adapter adapter;
    ListView list;
    String query="베트맨";
    String url="https://openapi.naver.com/v1/search/movie.json?";

    @Override
    protected void onCreate(Bundle savedInstanceState) { //메인스레드
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //#1 홈버튼 만들기
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_home);
        //#2-1 스레드 실행
        new NaverThread().execute();
        list=findViewById(R.id.list);
    }
    //#2 네이버API 스레드 만들기
    //스레드(=작업) 만들기(보조 스레드 만들기) AsyncTask;동시에 여러개 작업하기/비동기작업
    class NaverThread extends AsyncTask<String,String,String>{

        @Override
        protected String doInBackground(String... strings) {    //back에서 보조 스레드 작업하겠다
            //#2-3  결과값 교정하기
            String result= NaverAPI.search(query, url);
            return result;
        }
        //#2-3 위 result 결과값 받아온게 s에 들어가있음. > activity_main에서 레이아웃 작업 후 item res 만들어주기
        @Override
        protected void onPostExecute(String s) {
            try {
                array = new JSONObject(s).getJSONArray("items");
                adapter=new Adapter();
                list.setAdapter(adapter);

            }catch (Exception e) {
                System.out.println("GET_result___"+e.toString());
            }
            super.onPostExecute(s);
        }
    }
    //어댑터 만들기
    class Adapter extends BaseAdapter{

        @Override
        public int getCount() {
            return array.length();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view=getLayoutInflater().inflate(R.layout.item,parent,false);
            try {
                JSONObject obj=(JSONObject)array.get(position);
                String strTitle=obj.getString("title");
                String strActor=obj.getString("actor");
                String strImage=obj.getString("image");
                String strRating=obj.getString("userRating");
                float fltRating=Float.parseFloat(strRating);
                String strDirector=obj.getString("director");

                TextView title=view.findViewById(R.id.title);
                title.setText(Html.fromHtml(strTitle));

                TextView actor=view.findViewById(R.id.actor);
                actor.setText(Html.fromHtml(strActor));

                TextView director=view.findViewById(R.id.director);
                director.setText(Html.fromHtml(strDirector));

                RatingBar rating=view.findViewById(R.id.rating);
                rating.setRating(fltRating);
                ImageView image=view.findViewById(R.id.image);

                System.out.println(".............." + strImage);

                if(!strImage.equals("")){
                    Picasso.with(MainActivity.this)
                            .load(strImage)
                            .into(image);
                }

                final String strLink=obj.getString("link");
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent=new Intent(MainActivity.this,LinkActivity.class);
                        intent.putExtra("link", strLink);
                        startActivity(intent);
                    }
                });

            } catch (JSONException e) {
                System.out.println("오류:" + e.toString());
            }
            return view;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);

        MenuItem search=menu.findItem(R.id.search);
        SearchView searchView=(SearchView)search.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                query=newText;
                new NaverThread().execute();
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }
}