package com.example.ex03;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class AddressDB extends SQLiteOpenHelper {
    public AddressDB(@Nullable Context context){
        super(context, "address.db", null, 1);
    }
    public void onCreate(SQLiteDatabase db){
        String str="create table address(_id integer primary key autoincrement,";
        str += "name text, tel text, juso text);";
        db.execSQL(str);

        str="insert into address(name,tel,juso) values('홍길동','010-1010-1010','인천 서구 경서동');";
        db.execSQL(str);

        str="insert into address(name,tel,juso) values('심청이','010-2020-2020','인천 부평구 계산동');";
        db.execSQL(str);

        str="insert into address(name,tel,juso) values('강감찬','010-3030-3030','인천 남구 학익동동');";
        db.execSQL(str);

        str="insert into address(name,tel,juso) values('윤원식','010-4040-4040','인천 서구 경서동');";
        db.execSQL(str);

        str="insert into address(name,tel,juso) values('박소영','010-5050-5050','인천 부평구 계산동');";
        db.execSQL(str);

        str="insert into address(name,tel,juso) values('김파이','010-6060-7070','인천 남구 학익동동');";
        db.execSQL(str);

        str="insert into address(name,tel,juso) values('조한나','010-7070-8080','인천 서구 경서동');";
        db.execSQL(str);

        str="insert into address(name,tel,juso) values('장진우','010-8080-9090','인천 부평구 계산동');";
        db.execSQL(str);

        str="insert into address(name,tel,juso) values('윤원빈','010-9090-9090','인천 남구 학익동동');";
        db.execSQL(str);
    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

    }
}