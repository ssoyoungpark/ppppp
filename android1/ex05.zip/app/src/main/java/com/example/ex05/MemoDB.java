package com.example.ex05;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MemoDB extends SQLiteOpenHelper {
    public MemoDB(@Nullable Context context) {
        super(context, "memo.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table memo(_id integer primary key autoincrement, content text,date text)");
        db.execSQL("insert into memo(content,date) values('안드로이드','2014-08-20 12:20:22')");
        db.execSQL("insert into memo(content,date) values('HTML','2018-05-150 18:10:20')");
        db.execSQL("insert into memo(content,date) values('Java','2020-01-20 12:20:22')");
        db.execSQL("insert into memo(content,date) values('Jsp&Servlet','2021-04-20 22:01:00')");
        db.execSQL("insert into memo(content,date) values('데이타베이스','2022-05-20 18:40:59')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
