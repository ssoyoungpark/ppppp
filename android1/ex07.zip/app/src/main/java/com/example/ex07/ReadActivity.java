package com.example.ex07;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import de.hdodenhof.circleimageview.CircleImageView;

public class ReadActivity extends AppCompatActivity {
    AddressDB helper;
    SQLiteDatabase db;
    String strImage="";
    EditText name,tel;
    CircleImageView image;
    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        getSupportActionBar().setTitle("주소수정");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Button save=findViewById(R.id.save);
        save.setText("수정하기");
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder box=new AlertDialog.Builder(ReadActivity.this);
                box.setTitle("질의");
                box.setMessage("수정하실래요?");
                box.setPositiveButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String strName=name.getText().toString();
                        String strTel=tel.getText().toString();

                        String sql="update address set ";
                        sql += "name='" + strName + "',";
                        sql += "tel='" + strTel + "',";
                        sql += "image='" + strImage + "' ";
                        sql += "where _id=" + id;

                        db.execSQL(sql);
                        finish();
                    }
                });
                box.setNegativeButton("아니요",null);
                box.show();
            }
        });

        Intent intent=getIntent();
        id=intent.getIntExtra("id",0);

        helper=new AddressDB(this);
        db=helper.getWritableDatabase();
        String sql="select * from address where _id=" + id;
        Cursor cursor=db.rawQuery(sql, null);

        name=findViewById(R.id.name);
        tel=findViewById(R.id.tel);
        image=findViewById(R.id.image);

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 0);
            }
        });

        if (cursor.moveToNext()){
            name.setText(cursor.getString(1));
            tel.setText(cursor.getString(2));
            strImage=cursor.getString(3);
            image.setImageBitmap(BitmapFactory.decodeFile(strImage));

        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        finish();
        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        image.setImageURI(data.getData());

        //이미지 불러오기
        Cursor cursor=getContentResolver().query(data.getData(),null,null,null,null);
        if (cursor.moveToFirst()){
            strImage=cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
            System.out.println(".............." + strImage);
        }
    }
}