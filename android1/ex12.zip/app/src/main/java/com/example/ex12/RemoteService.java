package com.example.ex12;

import android.telecom.Call;

import java.util.List;

import retrofit2.http.GET;

public interface RemoteService {
    public static final String BASE_URL="http://192.168.0.188:3000";



    //사용자 목록
    @GET("/users/list.json")
    Call<List<UserVO>> list();
}
