package com.example.ex02;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    ArrayList<MovieVO> array=new ArrayList<>();
    ListView list;

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        getSupportActionBar().setTitle("연습2");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //1.데이타생성
        MovieVO vo=new MovieVO();
        vo.setImage(R.drawable.a1);
        vo.setTitle("해리포터");
        vo.setActor("다니엘 래드클리프");
        array.add(vo);

        vo=new MovieVO();
        vo.setImage(R.drawable.b);
        vo.setTitle("헝거게임");
        vo.setActor("제니퍼 로렌스");
        array.add(vo);

        vo=new MovieVO();
        vo.setImage(R.drawable.c);
        vo.setTitle("죠스");
        vo.setActor("로이 샤이더");
        array.add(vo);

        vo=new MovieVO();
        vo.setImage(R.drawable.a1);
        vo.setTitle("해리포터");
        vo.setActor("다니엘 래드클리프");
        array.add(vo);

        vo=new MovieVO();
        vo.setImage(R.drawable.b);
        vo.setTitle("헝거게임");
        vo.setActor("제니퍼 로렌스");
        array.add(vo);

        vo=new MovieVO();
        vo.setImage(R.drawable.c);
        vo.setTitle("죠스");
        vo.setActor("로이 샤이더");
        array.add(vo);

        vo=new MovieVO();
        vo.setImage(R.drawable.a1);
        vo.setTitle("해리포터");
        vo.setActor("다니엘 래드클리프");
        array.add(vo);

        vo=new MovieVO();
        vo.setImage(R.drawable.b);
        vo.setTitle("헝거게임");
        vo.setActor("제니퍼 로렌스");
        array.add(vo);

        vo=new MovieVO();
        vo.setImage(R.drawable.c);
        vo.setTitle("죠스");
        vo.setActor("로이 샤이더");
        array.add(vo);

        //2.리스트뷰 생성
        list=findViewById(R.id.list);
       //3.어댑터생성
        MovieAdapter adapter=new MovieAdapter();
        list.setAdapter(adapter);
    }

    //어댑터정의
    class MovieAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return array.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView=getLayoutInflater().inflate(R.layout.item_movie,parent,false);

            MovieVO vo=array.get(position);

            ImageView image=convertView.findViewById(R.id.image);
            image.setImageResource(vo.getImage());

            TextView title=convertView.findViewById(R.id.title);
            title.setText(vo.getTitle());

            TextView actor=convertView.findViewById(R.id.actor);
            actor.setText(vo.getActor());
            return convertView;
        }
    }
}