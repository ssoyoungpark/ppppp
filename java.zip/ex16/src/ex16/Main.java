package ex16;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
//		Example1.execute();
//		Example2.execute();
//		Example3.execute();
//		Example4.execute();
		
		
		Scanner s=new Scanner(System.in);
		boolean run=true;
		while(run) {
			System.out.println("==============");
			System.out.println("1. �ڵ�޴� ");
			System.out.println("2. Ÿ�Ը޴�");
			System.out.println("3. �л��޴� ");
			System.out.println("4. �����޴� ");
			System.out.println("==============");
			int menu=Main.input("����");
			switch(menu) {
			case 0:
				run=false;
					System.out.println("���θ޴��� ���ư��ϴ�.");
				break;
			case 1:
				Example1.execute();
				break;
			case 2:
				Example2.execute();
				break;
			case 3:
				Example3.execute();
				break;
			case 4:
				Example4.execute();
				break;
			default :
				System.out.println("�޴��� �ٽ� �������ּ���.");
			}
		}
	}
	
	//�����Է¹ޱ�
	   public static int input(String title) {
	      Scanner s=new Scanner(System.in);
	      String value="";
	      boolean isNumber=false;
	      do {
	         System.out.print(title + ">");
	         value=s.nextLine();
	         isNumber=value.matches("-?\\d+(\\.\\d+)?");
	         if(isNumber==false) System.out.println("���ڷ��Է��ϼ���!");
	      }while(isNumber==false);
	      
	      return Integer.parseInt(value);
	   }
}
