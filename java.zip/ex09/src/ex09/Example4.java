package ex09;

import java.io.*;
import java.util.*;

public class Example4 {
	public static void execute() {
		Scanner s=new Scanner(System.in);
		boolean run=true;
		File file=new File("c:/data/java/address.txt");
		
		while(run) {
			System.out.println("===================================================");
			System.out.println(" 1.�ּҵ�� | 2.�ּҰ˻� | 3.�ּҸ�� | 4.�ּһ��� | 0.����");
			System.out.println("===================================================");
			System.out.print("����>>");
			
			int menu=s.nextInt();s.nextLine();
			switch(menu) {
				case 0:
					run=false;
					System.out.println("���α׷��� �����մϴ�.");
					break;
				case 1: //�ּҵ��
					Address add=new Address();
					System.out.print("�̸�>");
					add.setName(s.nextLine());
					System.out.print("��ȭ��ȣ>");
					add.setTel(s.nextLine());
					System.out.print("�ּ�>");
					add.setJuso(s.nextLine());
					System.out.println(add.toString());
//					System.out.println(add.toString())
					//���Ͽ� ����
				try {
					FileWriter writer=new FileWriter(file,true);
					writer.write(add.getName()+"|"+add.getTel()+"|"+add.getJuso()+"\n");
					writer.flush();
					writer.close();
					System.out.println("�ּҰ� ��ϵǾ����ϴ�.");
				} catch (IOException e) {
					
					e.printStackTrace();
				}
					break;
				case 2:
					System.out.print("�˻����̸�>");
					String sname=s.nextLine();
					try {
						BufferedReader reader=new BufferedReader(new FileReader(file));
						String line="";
						boolean find=false;
						
						while((line=reader.readLine()) !=null ) {
							StringTokenizer st=new StringTokenizer(line, "|");
							add=new Address();
							add.setName(st.nextToken());
							add.setTel(st.nextToken());
							add.setJuso(st.nextToken());
							if(sname.equals(add.getName())) {//�̸��� ã������
								add.printList();
								find=true;
							}
							
						}
						if(find==false) System.out.println("�ش��л��� �����ϴ�.");
						reader.close();
					} catch (Exception e) {
						
						e.printStackTrace();
					}
					
					break;
				case 3://�ּҸ��
					try {
						BufferedReader reader=new BufferedReader(new FileReader(file));
						String line="";
						
						while((line=reader.readLine()) !=null ) {
							StringTokenizer st=new StringTokenizer(line, "|");
							add=new Address();
							add.setName(st.nextToken());
							add.setTel(st.nextToken());
							add.setJuso(st.nextToken());
							add.printList();
							
						}
						
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case 4:
					System.out.print("�������̸�>");
					String dname=s.nextLine();
					
					
					
					try {
						BufferedReader reader=new BufferedReader(new FileReader(file));
						String line="";
						String strLine="";
						boolean find=false;
						while((line=reader.readLine()) !=null ) {
							StringTokenizer st=new StringTokenizer(line, "|");
							add=new Address();
							add.setName(st.nextToken());
							add.setTel(st.nextToken());
							add.setJuso(st.nextToken());
							if(dname.equals(add.getName())) {//�̸��� ã������
								
								find=true;
							
							}else {
								//a=a+1, a==, a+=1
								//a=a+2, a+=2;
								//sum=sum + a, sum + =a;
								//strLine = add.getName() + "|"
								//     ||
								//     ||
								//     \/ 
								//    ���� ������� �ص� ������~ ������ �ؿ������ �� ���� �������ϴ�~
								
								
								strLine += add.getName() + "|";
								strLine += add.getTel() + "|";
								strLine += add.getJuso() + "\n";
							}
						}
						if(find==false) {
							System.out.println("�ش��ϴ� �̸��� �ּҰ� �����ϴ�.");
						}else {
							System.out.print("�����ϽǷ���??(Y)>>>>");
							String sel=s.nextLine();
							if(sel.equals("Y") || sel.equals("y") || sel.equals("��")) {
								FileWriter writer=new FileWriter(file, false);
								writer.write(strLine);
								writer.flush();
								writer.close();
								System.out.println(dname + "��(��) �����Ǿ����ϴ�.");
							}
							
						}
						
					}catch(Exception e) {}

					break;
				default:
					System.out.println("�޴��� �ٽ� �������ּ���.");
					
			}
		}
	}
}
