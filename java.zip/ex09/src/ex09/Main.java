package ex09;

public class Main {

	public static void main(String[] args) {
//		Example1.execute();
//		Example2.execute();
//		Example3.execute();
//		Example4.execute();
//		Example5.execute();
		

	}

}
