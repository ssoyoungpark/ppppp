package ex01;

public class Sample {

	public static void main(String[] args) {
		System.out.println("�ȳ��ϼ���!");

	}

}
