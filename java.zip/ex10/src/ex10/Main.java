package ex10;

public class Main {

	public static void main(String[] args) {
//		Example1.execute();
//		Example2.execute();
//		Example3.execute();
	}

}
