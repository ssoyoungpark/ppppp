package ex12;

import java.io.*;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class AccountDAOImpl implements AccountDAO{
	File file=new File("c:/data/java/ex12/account.txt");
	//�Ա� ���
	public void trade(int no, int price) {
		try {
			BufferedReader reader=new BufferedReader(new FileReader(file));
			String line="";
			String lines="";
			while((line=reader.readLine()) != null) {
				StringTokenizer st=new StringTokenizer(line, "|");
				
				AccountVO vo=new AccountVO();
				vo.setNo(Integer.parseInt(st.nextToken()));
				vo.setName(st.nextToken());
				int balance=Integer.parseInt(st.nextToken());
				vo.setBalance(balance + price);
				
				if(no==vo.getNo()) {
					lines=lines+vo.getNo()+"|"+vo.getName()+"|"+vo.getBalance()+"\n";
				}else {
					lines=lines + line + "\n";
				}
			}
								
			//���ο� ���ϻ���
			FileWriter writer=new FileWriter(file, false);
			writer.write(lines);
			writer.flush();
			writer.close();
			
			
		}catch(Exception e) {
			System.out.println("�Ա� ���: " + e.toString());
		}
	}
	
	//������ ���¹�ȣ ����������
	public int getLastNo() {
		int no=0;
		try {
			BufferedReader reader=new BufferedReader(new FileReader(file));
			String line="";
			while ((line=reader.readLine()) != null) {
				StringTokenizer st=new StringTokenizer(line, "|");
				no=Integer.parseInt(st.nextToken());
				
			}
		}catch(Exception e) {
			System.out.println("������ ���¹�ȣ: " + e.toString());
		}
		
		
		
		return no;
	}
	
	
	
	@Override
	public ArrayList<AccountVO> list() {
		ArrayList<AccountVO> array=new ArrayList<AccountVO>();
		try {
			BufferedReader reader=new BufferedReader(new FileReader(file));
			String line="";
			while((line=reader.readLine()) != null) {
				StringTokenizer st=new StringTokenizer(line, "|");
				AccountVO vo=new AccountVO();
				vo.setNo(Integer.parseInt(st.nextToken()));
				vo.setName(st.nextToken());
				vo.setBalance(Integer.parseInt(st.nextToken()));
				array.add(vo);
				
			}
		}catch(Exception e) {
			System.out.println("���: "+ e.toString());
		}
		return array;
	}
	//���»���
	@Override
	public void insert(AccountVO vo) {
		try {
			FileWriter writer=new FileWriter(file, true);
			writer.write(vo.getNo()+"|"+vo.getName()+"|"+vo.getBalance()+"\n");
			writer.flush();
			writer.close();
			
		}catch(Exception e) {
			System.out.println("���»���: " + e.toString());
		}
		
	}

	@Override
	public AccountVO read(int no) {
		AccountVO vo=new AccountVO();
		try {
			BufferedReader reader=new BufferedReader(new FileReader(file));
			String line="";
			while((line=reader.readLine()) != null) {
				StringTokenizer st=new StringTokenizer(line, "|");
				vo.setNo(Integer.parseInt(st.nextToken()));				
				if(no==vo.getNo()) {
					vo.setName(st.nextToken());
					vo.setBalance(Integer.parseInt(st.nextToken()));
					break;
					
				}
			}
		}catch(Exception e){
			System.out.println("���¹�ȣ: " + e.toString());
		}
		return vo;
	}

	@Override
	public void update(AccountVO vo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int no) {
		// TODO Auto-generated method stub
		
	}
	

}
