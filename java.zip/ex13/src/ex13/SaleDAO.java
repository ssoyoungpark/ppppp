package ex13;

import java.io.*;
import java.util.*;

public class SaleDAO {
	File file=new File("c:/data/java/ex13/sale.txt");
	//�Ǹŵ��
	public void insert(SaleVO vo) {
		try {
			FileWriter writer=new FileWriter(file, true);
			writer.write(vo.getNo()+"|"+vo.getDate()+"|"+vo.getQnt()+"\n");
			writer.flush();
			writer.close();
			
		}catch(Exception e) {
			System.out.println("�Ǹŵ��: " + e.toString());
		}
	}
	
	
	
	//Ư�� ��ǰ������ �ǸŸ��
	public ArrayList<SaleVO> list(int no) {
		ArrayList<SaleVO> array=new ArrayList<SaleVO>() ;
		try {
			BufferedReader reader=new BufferedReader(new FileReader(file));
			String line="";
			while((line=reader.readLine()) !=null) {
				StringTokenizer st=new StringTokenizer(line, "|");
				int lineNo=Integer.parseInt(st.nextToken());
				if(no==lineNo) {
					SaleVO vo=new SaleVO();
					vo.setNo(lineNo);
					vo.setDate(st.nextToken());
					vo.setQnt(Integer.parseInt(st.nextToken()));
					array.add(vo);
					
				}
			}
		}catch(Exception e) {
			System.out.println("�ǸŸ��: " + e.toString());
		}
		return array;
		
	}
}
