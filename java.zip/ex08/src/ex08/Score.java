package ex08;

public class Score extends Stu{

	private String type;
	private int grade;
	
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	
	@Override //������
	public void print() {
		super.print();
		System.out.println("����: "+ type);
		System.out.println("����: "+ grade);
	}
	
	
	
}
