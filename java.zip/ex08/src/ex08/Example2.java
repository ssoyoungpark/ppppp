package ex08;

public class Example2 {
	public static void execute() {
		Score s1=new Score();
		s1.setNo(10);
		s1.setName("ȫ�浿");
		s1.setDept("����");
		s1.setType("�⸻");
		s1.setGrade(100);
		s1.print();
		
		
		
	}

}
