package ex07;

public class Example1 {
	public static void execute() {
		System.out.println("**************** ���� 1 ****************");
		
		Area a1=new Area();
		
		System.out.println("");
		
		Area a2=new Area();
		
		System.out.println("����:"+ a2.area(5));
		System.out.println("");
		
		Area a3=new Area();
		
		System.out.println("����:"+ a3.area(3, 4));
		System.out.println("");
		
	}
}
