package ex17;

import java.sql.*;
import java.util.*;

public class TypeDAO {
	Connection con=Database.getConnection();
	
	
	
	//����
	public boolean delete(String tcode) {
		try {
			String sql="delete from tbl_type where tcode=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, tcode);			
			ps.execute();
			return true;
		}catch(Exception e) {
//			System.out.println("����: " + e.toString());
			return false;
		}
	}
	//Ư��ķ���忡 Ư�������˻�
	public TypeVO read(String code,String tcode) {
		TypeVO vo=new TypeVO();
		try {
			String sql="select * from view_type where code=? and tcode=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, code);
			ps.setString(2, tcode);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {				
				vo.setCode(rs.getString("code"));
				vo.setTcode(rs.getString("tcode"));
				vo.setTname(rs.getString("tname"));	
				vo.setQnt(rs.getInt("qnt"));
			}
		}catch(Exception e) {
			System.out.println("��ȸ: "+ e.toString());
		}
		
		return vo;
	}
	
	//��ȸ
	public TypeVO read(String tcode) {
		TypeVO vo=new TypeVO();
		try {
			String sql="select * from tbl_type where tcode=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, tcode);
			
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {				
				vo.setTcode(rs.getString("tcode"));
				vo.setTname(rs.getString("tname"));				
			}
		}catch(Exception e) {
			System.out.println("��ȸ: "+ e.toString());
		}
		
		return vo;
	}
	
	//ķ���� �������
	public void insert(TypeVO vo) {
		try {
			String sql="insert into tbl_camp_type(code,tcode,qnt) values(?,?,?)";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, vo.getCode());
			ps.setString(2, vo.getTcode());
			ps.setInt(3, vo.getQnt());
			ps.execute();
		}catch(Exception e) {
			System.out.println("���: " + e.toString());
		}
		
	}
	
	//ķ���� ��������
	public void delete(String code, String tcode) {
		try {
			String sql="delete from tbl_camp_type where code=? and tcode=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, code);
			ps.setString(2, tcode);	
			ps.execute();
		}catch(Exception e) {
			System.out.println("����: " + e.toString());
		}
	}
	
	//���
	public void insert(String tcode,String tname) {
		try {
			String sql="insert into tbl_type(tcode,tname) values(?,?)";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, tcode);
			ps.setString(2, tname);
			ps.execute();
		}catch(Exception e) {
			System.out.println("���: " + e.toString());
		}
	}
	
	
	
	//New Code���ϱ�
	public String getNewCode() {
		String newCode="";
		try {
			String sql="select max(tcode) mcode from tbl_type";
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				String maxCode=rs.getString("mcode");
				int code=Integer.parseInt(maxCode.substring(1)) +10;
				newCode = "t" + code;
			}
		}catch(Exception e) {
			System.out.println("���: "+ e.toString());
		}
		return newCode;
	}
	
	
	//�������
	public ArrayList<TypeVO> list(){
		ArrayList<TypeVO> array=new ArrayList<TypeVO>();
		try {
			String sql="select * from tbl_type";
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				TypeVO vo=new TypeVO();
				vo.setTcode(rs.getString("tcode"));
				vo.setTname(rs.getString("tname"));
				array.add(vo);
			}
		}catch(Exception e) {
			System.out.println("���: "+ e.toString());
		}
		
		return array;
	}
	
	
	
	//Ư�� ķ������ �������
	public ArrayList<TypeVO> list(String code){
		ArrayList<TypeVO> array=new ArrayList<TypeVO>();
		try {
			String sql="select * from view_type where code=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, code);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				TypeVO vo=new TypeVO();
				vo.setCode(rs.getString("code"));
				vo.setTcode(rs.getString("tcode"));
				vo.setTname(rs.getString("tname"));
				vo.setQnt(rs.getInt("qnt"));
				array.add(vo);
			}
		}catch(Exception e) {
			System.out.println("�������:" + e.toString());
		}
		
		
		return array;
		
	}
	
	
}
