package ex02;

public class Double {
	public static void doubleExample() {
		System.out.println("�Ǽ��� ����(double)");
		double a=2.1234;
		double b=6.123;
		double c=a+b;
		double d=a-b;
		double e=a*b;
		double f=a/b;
		
		System.out.println(a+"+"+b+"="+c);
		System.out.println(a+"-"+b+"="+d);
		System.out.println(a+"*"+b+"="+e);
		System.out.println(a+"/"+b+"="+f);
}
}