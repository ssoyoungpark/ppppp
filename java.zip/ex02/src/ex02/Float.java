package ex02;

public class Float {
	public static void floatExample() {
//		�Ǽ�������
		System.out.println("�Ǽ�������~~");
		float a=3.14f;
		float b=5.12f;
		float c= a + b;
		float d= a - b;
		float e= a * b;
		float f= a / b;
		System.out.println(a + "+" + b + "=" + c);
		System.out.println(a + "-" + b + "=" + d);
		System.out.println(a + "*" + b + "=" + e);
		System.out.println(a + "/" + b + "=" + f);
}
}