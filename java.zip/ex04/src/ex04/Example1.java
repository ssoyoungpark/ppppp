package ex04;

import java.util.Scanner;

public class Example1 {
	public static void execute() {
		Scanner s=new Scanner(System.in);
		System.out.println("**************����ǥ**************");
		
		boolean run=true;
		while(run) {
			System.out.println("�̸�>");
			String name=s.next();
			
			System.out.println("����:");
			int k=s.nextInt();
				
			System.out.println("����:");
			int e=s.nextInt();
				
			System.out.println("����:");
			int m=s.nextInt();
				
			int tot =k + e + m;
			System.out.println("����:"+ tot);
			double avg=tot /(double)3;
			System.out.println("���:"+ avg);
			
			String grade="";
			
				
				
				if (avg>=90) {
					if(avg>=95) {
						grade="A+";
					}else {
						grade="A0";
					}
				}else if (avg>=80) {
					if (avg>=85) {
						grade="B+";
					}else {
						grade="B0";
					}
				}else if (avg>=70) {
					if (avg>75) {
						grade="C+";
					}else {
						grade="C0";
					}
				}
				System.out.println("���:"+ grade);
				System.out.println("����:0, ���:1>");
				int sel=s.nextInt();
				
				if(sel == 0) { //����
					System.out.println("���α׷��� �����մϴ�.");
					run=false;
			}
		
			
			
		}
	}
}
