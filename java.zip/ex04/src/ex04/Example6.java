package ex04;

import java.text.DecimalFormat;

public class Example6 {
	public static void execute() {
		
		DecimalFormat df=new DecimalFormat("###.00"); 
		
		String[] name= {"ȫ�浿", "������", "�̼���"};
		int[] kor= {98 , 67, 78};
		int[] eng= {78 , 66, 88};
		int[] mat= {43 , 76, 95};
		
		System.out.println("�̸�"+"\t" +"����" +"\t" + "����" +"\t" + "����" +"\t" + "����" +"\t" + "���");
		
		for(int i=0; i<name.length; i=i+1) {
			int tot=kor[i] + eng[i] + mat[i];
			double avg=tot/3.;  //double avg=tot/(double)3;
			System.out.print(name[i] + "\t");
			System.out.print(kor[i] + "\t");
			System.out.print(eng[i] + "\t");
			System.out.print(mat[i] + "\t");
			System.out.print(tot + "\t");
			System.out.println(df.format(avg));
			System.out.println("--------------------------------------------");
			
		}   
		
		
	}
}
