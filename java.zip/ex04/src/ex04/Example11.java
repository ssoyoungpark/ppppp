package ex04;

import java.util.Scanner;

public class Example11 {
	public static void execute() {
		Scanner s=new Scanner(System.in);
		System.out.println("**** ��ǰ ���� ��Ȳ ****");
		
		while(true) {
			System.out.println("��ǰ��:");
			String r=s.next();
			System.out.println("�ܰ�:");
			int e=s.nextInt();
			System.out.println("����:");
			int y=s.nextInt();
			
			System.out.println("�Ǹűݾ�:");
		}
		
		
	}
}
