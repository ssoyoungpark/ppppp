package ex04;

public class Main {

	public static void main(String[] args) {
//		Example1.execute();
//		Example2.execute();
//		Example3.ececute();
//		Example4.execute();
//		Example5.execute();
//		Example6.execute();
//		Example7.excute();
		
//		Example11.execute();  //����
//		Example22.execute();  //����
	}

}
