package ex04;

public class Example22 {
	public static void execute( ) {
		
	}
}
