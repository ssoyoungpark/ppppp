//1~100합계 구하기
tot=0;
for(i=1;i<=100;i=i+1){
    tot=tot+i;
    
}

alert("1~100까지의 합은=" + tot);