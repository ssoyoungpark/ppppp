package com.example.service.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.dao.like.LikedDAO;
import com.example.dao.report.ReportDAO;
import com.example.dao.review.ReviewDAO;
import com.example.dao.user.UserDAO;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserDAO udao;
	
	@Autowired
	ReviewDAO reviewdao;
	
	@Autowired
	ReportDAO reportdao;
	
	@Autowired
	LikedDAO ldao;

	@Transactional
	@Override
	public void delUser(String u_code) {
		udao.updateStatus(u_code);
		udao.delUser(u_code);
	}

	
	@Transactional
	@Override
	public void reUser(String u_code) {
		udao.updateStatus(u_code);
		udao.reUser(u_code);		
	}
	
	@Transactional
	@Override
	public void del_user() {
		reviewdao.update_del();
		reportdao.update_del();
		ldao.u_delete();
		udao.del_user();
	}
	
	
	
}
