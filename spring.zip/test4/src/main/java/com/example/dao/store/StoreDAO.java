package com.example.dao.store;

import java.util.List;

import com.example.domain.StoreVO;

public interface StoreDAO {
	
	public List<StoreVO> list();
	
	public StoreVO read(String s_code);
	
	public String newCode();
	
	public void insert(StoreVO storeVO);
	
	public void update(StoreVO storeVO);
	
	public void delete(String s_code);
	
	public List<StoreVO> clist(int s_c_code);

	
	
}
