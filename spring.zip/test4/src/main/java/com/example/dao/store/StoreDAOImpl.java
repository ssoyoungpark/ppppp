package com.example.dao.store;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.domain.StoreVO;

@Repository
public class StoreDAOImpl implements StoreDAO {

	@Autowired
	SqlSession session;
	
	String namespace = "com.example.mapper.StoreMapper";

	@Override
	public List<StoreVO> list() {
		return session.selectList(namespace + ".list");
	}

	@Override
	public StoreVO read(String s_code) {
		return session.selectOne(namespace + ".read", s_code);
	}

	@Override
	public String newCode() {
		return session.selectOne(namespace + ".newCode");
	}

	@Override
	public void insert(StoreVO storeVO) {
		session.insert(namespace + ".insert", storeVO);
	}

	@Override
	public void update(StoreVO storeVO) {
		session.update(namespace + ".update", storeVO);
	}

	@Override
	public void delete(String s_code) {
		session.delete(namespace + ".delete", s_code);
	}

	@Override
	public List<StoreVO> clist(int s_c_code) {
		return session.selectList(namespace+".clist",s_c_code);
	}
	
}
