package com.example.dao.review;

import java.util.HashMap;
import java.util.List;

import com.example.domain.ReviewVO;

public interface ReviewDAO {
	public List<ReviewVO> list();
	public List<HashMap<String, Object>> uread(String u_code);
	public List<HashMap<String, Object>> sread(String s_code);
	public void insert(ReviewVO vo);
	public void delete(String u_code);
	public List<ReviewVO> list(String s_code);
	public void update_del();
}
