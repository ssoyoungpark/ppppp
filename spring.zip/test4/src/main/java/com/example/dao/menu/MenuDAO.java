package com.example.dao.menu;

import java.util.List;

import com.example.domain.MenuVO;

public interface MenuDAO {
	public int newCode(String s_code);
	public void insert(MenuVO vo);
	public MenuVO read(String s_code, String m_name);
	public List<MenuVO> list(String s_code);
	public void update(MenuVO vo);
	public void mdelete(String s_code, String m_name);
	public void sdelete(String s_code);
}
