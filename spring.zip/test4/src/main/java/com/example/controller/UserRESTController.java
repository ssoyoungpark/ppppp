package com.example.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.user.UserDAO;
import com.example.domain.UserVO;
import com.example.service.user.UserService;

@RestController
@RequestMapping("/api/user")
public class UserRESTController {
	@Autowired
	UserDAO udao;
	
	@Autowired
	UserService uservice;
	
	@Autowired
	PasswordEncoder encoder;
	
	@RequestMapping(value="/insert", method=RequestMethod.POST)
	public void insert(@RequestBody UserVO userVO) {
		userVO.setU_code(udao.newCode());
		userVO.setU_pass(encoder.encode(userVO.getU_pass()));
		System.out.println(userVO.toString());
		udao.insert(userVO);
	}
	
	@RequestMapping("/list")
	public HashMap<String, Object> list(String column, String query, int page, int num){
		HashMap<String, Object> map= new HashMap<>();
		map.put("list",udao.list(column, query, page, num));
		map.put("total", udao.total(column, query));
		return map;
	}
	
	@RequestMapping(value="/delete/{u_code}",method=RequestMethod.POST)
	public void delUser(@PathVariable String u_code){
		uservice.delUser(u_code);
	}
	
	@RequestMapping(value="/recover/{u_code}",method=RequestMethod.POST)
	public void reUser(@PathVariable String u_code){
		uservice.reUser(u_code);
	}
	
	@RequestMapping("/read/{u_code}")
	public UserVO read(@PathVariable String u_code) {
		UserVO vo = udao.read(u_code);
		return vo;
	}
	
	@RequestMapping(value="/del_user",method = RequestMethod.POST)
	public void del_user(){
		System.out.println("zzz");
		uservice.del_user();
	}
	
	// �α��� üũ
		@RequestMapping(value = "/login", method = RequestMethod.POST)
		public HashMap<String, Object> login(@RequestBody UserVO vo) {
			System.out.println(vo.toString());
			HashMap<String, Object> map = new HashMap<String, Object>();
			int result = 0;
			int u_type = 0;
			UserVO readvo = udao.loginRead(vo.getU_id());
			if (readvo != null) {
				if (encoder.matches(vo.getU_pass(),readvo.getU_pass())) {
					result = 2;
					u_type = readvo.getU_type();
				} else {
					result = 1;
				}
			}
			map.put("check", result);
			map.put("u_type", u_type);
			return map;
		}
	
	
}
