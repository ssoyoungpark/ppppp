package com.example.controller;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.example.dao.menu.MenuDAO;
import com.example.domain.MenuVO;

@RestController
@RequestMapping("/api/menu")
public class MenuRestController {
	@Autowired
	MenuDAO dao;
	
	@RequestMapping(value="/insert", method=RequestMethod.POST)
	public int insert(MenuVO menuVO, MultipartHttpServletRequest multi) {
		try {
			if(multi.getFile("file") != null) {
				MultipartFile file = multi.getFile("file");
				String path = "/upload/menu/";
				File newPath = new File("c:/" + path);
				if(!newPath.exists()) newPath.mkdir();
				
				String fileName = file.getOriginalFilename();
				File newFile = new File(newPath + "/" + fileName);
				if(!newFile.exists()) file.transferTo(newFile);
				
				menuVO.setM_photo(path + fileName);
			}
			menuVO.setM_code(dao.newCode(menuVO.getS_code()));
			System.out.println(menuVO.toString());
			dao.insert(menuVO);
			return 1;
		} catch(Exception e) {
			System.out.println(e.toString());
			return 2;
		}
	}
	
	@RequestMapping("/list/{s_code}")
	public List<MenuVO> list(@PathVariable String s_code){
		return dao.list(s_code);
	}
	
	@RequestMapping("/read")
	public MenuVO read(@RequestBody MenuVO vo){
		return dao.read(vo.getS_code(),vo.getM_name());
	}
		
	
	@RequestMapping(value="/update", method=RequestMethod.POST)
	public void update(@RequestBody MenuVO vo){
		dao.update(vo);
	}
	
	@RequestMapping(value="/delete", method=RequestMethod.POST)
	public void delete(@RequestBody MenuVO vo){
		dao.mdelete(vo.getS_code(),vo.getM_name());
	}
}
