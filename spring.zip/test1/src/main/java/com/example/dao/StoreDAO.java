package com.example.dao;

import java.util.List;

import com.example.domain.StoreVO;

public interface StoreDAO {
	public List<StoreVO> list();
	public void insert(StoreVO storevo);
	public StoreVO read(String s_code);
	public void update(StoreVO storevo);
}
