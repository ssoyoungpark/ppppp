package com.example.dao;

import java.util.List;

import com.example.domain.MenuVO;
import com.example.domain.StoreVO;

public interface MenuDAO {
	public List<MenuVO> list();
	public void insert(MenuVO menuvo);
	public MenuVO read(String s_code);
	public void update(MenuVO menuvo);
	public void delete(String s_code);
}
