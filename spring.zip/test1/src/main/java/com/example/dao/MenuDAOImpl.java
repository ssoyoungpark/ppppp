package com.example.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.domain.MenuVO;

@Repository
public class MenuDAOImpl implements MenuDAO{
	
	@Autowired
	SqlSession session;
	String namespace="com.example.mapper.MenuMapper";

	@Override
	public List<MenuVO> list() {
		return session.selectList(namespace + ".list");
	}

	@Override
	public void insert(MenuVO menuvo) {
		session.insert(namespace + ".insert" , menuvo);
		
	}

	@Override
	public MenuVO read(String s_code) {
		return session.selectOne(namespace + ".read" , s_code);
	}

	@Override
	public void update(MenuVO menuvo) {
		session.update(namespace + ".update" , menuvo);
		
	}

	@Override
	public void delete(String s_code) {
		session.delete(namespace + ".delete", s_code);
		
	}

}
