package com.example.domain;

public class LikedVO {
	private String u_code;
	private String s_sode;
	public String getU_code() {
		return u_code;
	}
	public void setU_code(String u_code) {
		this.u_code = u_code;
	}
	public String getS_sode() {
		return s_sode;
	}
	public void setS_sode(String s_sode) {
		this.s_sode = s_sode;
	}
	@Override
	public String toString() {
		return "LikedVO [u_code=" + u_code + ", s_sode=" + s_sode + "]";
	}
	
	
}
