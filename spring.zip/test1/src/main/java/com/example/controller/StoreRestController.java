package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.StoreDAO;
import com.example.domain.StoreVO;


@RestController
@RequestMapping("/api/store")
public class StoreRestController {
	@Autowired
	StoreDAO dao;
	
	@RequestMapping("/list")
	public List<StoreVO> list(){
		return dao.list();
	}
	
	@RequestMapping("/read/{s_code}")
	public StoreVO read(String s_code){
		return dao.read(s_code);
	}
	
	
}
