package com.example.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.example.dao.MenuDAO;
import com.example.dao.StoreDAO;
import com.example.domain.MenuVO;
import com.example.domain.StoreVO;
import com.example.mapper.MysqlMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
public class MysqlTest {	
	
	@Autowired
//	StoreDAO dao;
	MenuDAO dao;
	
	@Transactional
	@Test
	public void list(){
//		dao.list();
	}
	
	@Test
	public void read(){
//		dao.read("s4");
	}
	
//	@Transactional
//	@Test
//	public void insert(){
//		StoreVO vo=new StoreVO();
//		vo.setS_code("s4");
//		vo.setS_name("s4");
//		vo.setS_admin("s4");
//		vo.setS_location("s4");
//		vo.setS_tel("s4");
//		vo.setS_c_code(5);
//		
//		dao.insert(vo);
//		
//		
//		
//	}
//	
	
	@Transactional
	@Test
	public void delete(){
//		dao.delete("s4");
	}
	
	
	@Transactional
	@Test
	public void insert(){
		MenuVO vo=new MenuVO();
		vo.setS_code("s1");
		vo.setM_name("��");
		vo.setM_price(1);
		dao.insert(vo);
		
		
		
	}
	
}
