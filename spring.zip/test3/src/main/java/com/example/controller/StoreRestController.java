package com.example.controller;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.example.dao.StoreDAO;
import com.example.domain.StoreVO;
import com.example.domain.UserVO;


@RestController
@RequestMapping("/api/store")
public class StoreRestController {
	@Autowired
	StoreDAO dao;
	
	@RequestMapping("/list")
	public List<StoreVO> list(){
		return dao.list();
	}
	
	@RequestMapping("/read/{s_code}")
	public StoreVO read(@PathVariable String s_code){
//		StoreVO vo=dao.read(s_code);
		return dao.read(s_code);
	}
	@RequestMapping(value="/insert", method=RequestMethod.POST)
	public void insert(StoreVO vo, MultipartFile file)throws Exception{
		if(!file.isEmpty()){
			String path="/upload/photo";
			File newFile=new File("c:" + path + file.getOriginalFilename());
			if(!newFile.exists())file.transferTo(newFile);
			vo.setS_photo(path + file.getOriginalFilename());
		}
		dao.insert(vo);
	}
	
	@RequestMapping(value="/update", method=RequestMethod.POST)
	public void update(@RequestBody StoreVO vo){
		dao.update(vo);
	}
	
	@RequestMapping(value="/delete/{s_code}", method=RequestMethod.POST)
	public void delete(@PathVariable String s_code){
		dao.delete(s_code);
	}
	
	
//	@RequestMapping("/delete/{s_code}")
//	public void delete(@PathVariable String s_code){
//		dao.delete(s_code);
//	}
	
	
	
	
	
	

	
}
