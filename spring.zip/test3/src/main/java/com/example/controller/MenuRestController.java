package com.example.controller;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.example.dao.MenuDAO;
import com.example.domain.MenuVO;

@RestController
@RequestMapping("/api/menu")
public class MenuRestController {

	@Autowired
	MenuDAO dao;

	@RequestMapping("/list/{s_code}")
	public List<MenuVO> list(@PathVariable String s_code) {
		return dao.list(s_code);
	}

	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public void insert(MenuVO vo, MultipartHttpServletRequest multi) throws Exception {
		MultipartFile file = multi.getFile("file");
		String path = "/upload/menu/";
		File newPath = new File("c:/" + path);

		

		if (multi.getFile("file") != null) {
			if (!newPath.exists())
				newPath.mkdir();
			String fileName = file.getOriginalFilename();
			File newFile = new File(newPath + "/" + fileName);
			if (!newFile.exists())
				file.transferTo(newFile);

			vo.setM_photo(path + fileName);
		}

		vo.setM_code(dao.newCode(vo.getS_code()));

		dao.insert(vo);
	}
}