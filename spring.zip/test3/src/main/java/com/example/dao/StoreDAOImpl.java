package com.example.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.domain.StoreVO;

@Repository
public class StoreDAOImpl implements StoreDAO{

	@Autowired
	SqlSession session;
	String namespace="com.example.mapper.StoreMapper";
	
	@Override
	public List<StoreVO> list() {
		return session.selectList(namespace + ".list");
	}

	@Override
	public void insert(StoreVO storevo) {
		session.insert(namespace + ".insert" ,storevo);
		
	}

	@Override
	public StoreVO read(String s_code) {
		return session.selectOne(namespace + ".read", s_code);
	}

	@Override
	public void update(StoreVO storevo) {
		session.update(namespace + ".update", storevo);
		
	}

	@Override
	public void delete(String s_code) {
		session.delete(namespace + ".delete", s_code);
		
	}

	

}
