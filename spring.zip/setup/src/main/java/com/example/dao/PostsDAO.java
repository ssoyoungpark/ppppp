package com.example.dao;

import java.util.HashMap;
import java.util.List;

import com.example.domain.PostVO;

public interface PostsDAO {
	public List<HashMap<String, Object>> list(); 
	public void insert(PostVO vo);
	public PostVO read (int id);
	public void update(PostVO vo);
	public void delete(int id);
}
