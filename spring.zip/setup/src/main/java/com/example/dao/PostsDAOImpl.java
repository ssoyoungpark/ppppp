package com.example.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.domain.PostVO;

@Repository
public class PostsDAOImpl implements PostsDAO{
   @Autowired
   SqlSession session;
   String namespace="com.example.mapper.PostsMapper";
   
   @Override
   public List<HashMap<String, Object>> list() {
      return session.selectList(namespace + ".list")  ;
   }

   @Override
   public void insert(PostVO vo) {
      session.insert(namespace + ".insert", vo); 
      
   }

   @Override
   public PostVO read(int id) {
      
      return session.selectOne(namespace + ".read" , id);
   }

   @Override
   public void update(PostVO vo) {
      session.update(namespace + ".update" ,vo); 
      
   }

@Override
public void delete(int id) {
	session.delete(namespace + ".delete", id);
	
}

}
