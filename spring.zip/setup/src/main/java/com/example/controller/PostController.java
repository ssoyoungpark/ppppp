package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.dao.PostsDAO;
import com.example.domain.PostVO;

@Controller
public class PostController {
   @Autowired
   PostsDAO dao;
   @RequestMapping(value="/posts")
   public String list(Model model){
      model.addAttribute("list", dao.list());
      return "post/list";
   }
   @RequestMapping(value="/post/insert")
   public String insert(){
      return "/post/insert";
   }
   
   @RequestMapping(value="/post/insert", method=RequestMethod.POST)
   public String insert(PostVO vo){
      dao.insert(vo);
      return "redirect:/posts";
   }
   @RequestMapping(value="/post/read")
   public String read(int id, Model model){
	   model.addAttribute("vo", dao.read(id));
      return "/post/read";
   }
   
   @RequestMapping(value="/post/update", method=RequestMethod.POST)
   public String update(PostVO vo){
	  System.out.println(vo.toString());
      dao.update(vo);
      return "redirect:/posts";
   }
   
   @RequestMapping(value="/post/delete", method=RequestMethod.POST)
   public String delete(PostVO vo){
	  System.out.println(vo.toString());
      dao.delete(vo.getId());
      return "redirect:/posts";
   }
}