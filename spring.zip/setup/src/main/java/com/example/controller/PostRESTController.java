package com.example.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.PostsDAO;
import com.example.domain.PostVO;

@RestController
@RequestMapping("/api")
public class PostRESTController {
	@Autowired
	PostsDAO dao;
	
	@RequestMapping("/post/list")
	public List<HashMap<String, Object>> list(){
		return dao.list();
	}
	
	@RequestMapping("/post/read")
	public PostVO read(int id){
		return dao.read(id);
		
	}
	
	@RequestMapping(value="/post/insert", method=RequestMethod.POST)
	   public String insert(@RequestBody PostVO vo){
	      dao.insert(vo);
	      return "sucess";
	   }
	
	@RequestMapping(value="/post/update", method=RequestMethod.POST)
	   public String update(@RequestBody PostVO vo){
	      dao.update(vo);
	      return "sucess";
	   }
	
	@RequestMapping(value="/post/delete", method=RequestMethod.POST)
	   public void delete(@RequestBody PostVO vo){
	      dao.delete(vo.getId());
	      
	   }
	

}
