package com.example.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.example.dao.PostsDAO;
import com.example.domain.PostVO;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"file:src/main/webapp/WEB-INF/spring/**/*.xml"})
public class MysqlTest {

	@Autowired
	PostsDAO pdao;

	@Test
	public void list(){
		pdao.list();
	}


	@Test
	public void update(){
		PostVO vo=new PostVO();
		vo.setTitle("�����߰��� �����Դϴ�....");
		vo.setBody("�׽�Ʈ���Դϴ�.....");
		vo.setId(254);
		pdao.update(vo);
	}
	
	@Test
	public void read(){
		pdao.read(252);
	}


	@Test
	public void insert(){
		PostVO vo=new PostVO();
		vo.setTitle("�����߰��� �����Դϴ�....");
		vo.setUserid("red");
		vo.setBody("�׽�Ʈ���Դϴ�.....");
		pdao.insert(vo);
	}

	@Test
	public void delete(){
		pdao.delete(254);
	}

}