package com.example.service;

import com.example.domain.TradeVO;

public interface TradeService {
	public void trade(TradeVO vo);
}
