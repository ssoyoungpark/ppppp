var express = require('express');
var router = express.Router();
var db = require('../db');

/* best 상품 목록 */
router.get('/', function(req, res) {
  var sql='select *, format(price,3) fprice from best where isShow=true';
  db.get().query(sql, function(err, rows){
    res.send(rows);
  })
});

/* 전체 목록 */
router.get('/list', function(req, res) {
    var sql='select *, format(price,3) fprice from best best order by id desc';
    db.get().query(sql, function(err, rows){
      res.send(rows);
    })
  });


  
module.exports = router;
