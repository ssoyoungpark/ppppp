var express = require('express');
var router = express.Router();
var db = require('../db')
/* GET users listing. */
router.get('/', function(req, res, next) {
  res.render("list");
});


//GET 사용자 목록데이터
router.get("/list.json",function(req,res){
  var sql="select * from users";
  db.get().query(sql,function(err,rows){
    res.send(rows);
  })
})

//GET 사용자 등록 페이지
router.get("/insert", function(req,res){
  res.render("insert");

})

//POST 사용자 등록
router.post("/insert",function(req,res){
  var id=req.body.id;
  var name=req.body.name;
  var pass=req.body.pass;
  var sql='insert into users(id,name,pass) values(?,?,?)';
  db.get().query(sql, [id,name,pass],function(err, rows){
    if(err) res.sendStatus(400);
    else res.sendStatus(200);
  })
})

//POST 사용자 삭제
router.post("/delete", function(req,res){
  var id=req.body.id;
  
  var sql='delete from users where id=?';
  db.get().query(sql,[id],function(err,rows){
    if(err) res.sendStatus(400);
    else res.sendStatus(200);
  })
})

//GET 사용자 정보 READ
router.get('/read.json',function(req,res){
  var id=req.query.id;
  console.log('id=' + id);
  var sql='select * from users where id=?';
  db.get().query(sql, [id], function(err, rows){
    res.send(rows[0])
  });
})

//GET 사용자 수정 페이지
router.get('/update',function(req, res){
  var id=req.query.id;
  res.render('update', {userid:id});
});

//POST 사용자 정보 수정
router.post("/update",function(req,res){
  var id=req.body.id;
  var name=req.body.name;
  var pass=req.body.pass;
  
  var sql='update users set name=?,pass=? where id=?';
  
  db.get().query(sql, [name,pass,id],function(err, rows){
    if(err) res.sendStatus(400);
    else res.sendStatus(200);
  })
})
module.exports = router;