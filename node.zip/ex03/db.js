var mysql=require('mysql');
var connection;

exports.connect=function(){
    connection=mysql.createPool({
        connectionLimit:100,
        host:'localhost',
        user:'node',
        password:'pass',
        database:'nodedb'
    })
}

exports.get=function(){
    return connection;
}