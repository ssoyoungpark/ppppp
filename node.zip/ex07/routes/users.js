const { request, query } = require('express');
var express = require('express');
var router = express.Router();
var db = require('../db');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

//GET 로그인 페이지
router.get('/login', function(req, res){
  res.render('index',{title:'로그인', pageName:'users/login.ejs', userid:req.session.userid})
});

//로그인 체크
router.post('/login', function(req, res){
  var userid=req.body.userid;
  var password=req.body.password;
  var check=req.body.check;

  
  var sql='select * from users where userid=?';
  var result=0;  //아이디가 없는경우

  db.get().query(sql,[userid],function(err, rows){
    if(rows.length > 0){
      if(rows[0].password == password){
        result=1; //로그인 성공
        req.session.userid=userid;
        //로그인상채유지
        if(check==1){
          res.cookie('userid', userid, {maxAge:60*60 * 24})
        }
      }else{
        result=2; //비밀번호가 틀린경우
      }
    }
    res.send({result:result});
  })
});

//로그아웃페이지
router.get('/logout', function(req, res){
  req.session.destroy(); //세션값삭제
  res.clearCookie('userid'); //쿠키값삭제
  res.redirect('/');
})
module.exports = router;
