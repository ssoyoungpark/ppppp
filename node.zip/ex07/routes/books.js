var express = require('express');
var router = express.Router();
var db = require('../db');

/* 최근도서 5권 */
router.get('/new.json', function(req, res, next) {
    var sql='select * from books order by code desc limit 0,5';
    db.get().query(sql, function(err, rows){
        res.send(rows);
    })
});

//베스트도서 5권
router.get('/best.json', function(req, res, next) {
    var sql='select * from books order by qnt desc limit 0,5';
    db.get().query(sql, function(err, rows){
        res.send(rows);
    })
});
module.exports = router;
