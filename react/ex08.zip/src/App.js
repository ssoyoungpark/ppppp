import { Link, Route } from 'react-router-dom';
import './App.css';
import BestPage from './component/BestPage';
import HomePage from './component/HomePage';


function App() {
  return (
    <div className='App'>
        <div className='menu'>
            <Link to="/">Home</Link>
            <Link to="/best">Best</Link>
        </div>
      
        <Route path="/" component={HomePage} exact/>
        <Route path="/best" component={BestPage}/>
    </div>
  );
}

export default App;
