import React from 'react'
import { Link, Route } from 'react-router-dom'
import BestList from './BestList'

const BestPage = () => {
    return (
        <div>
            <div className='sub_menu'>
                <Link to="/best/list">Best List</Link>
            </div>
            <Route path="/best/list" component={BestList}/>
        </div>
    )
}

export default BestPage