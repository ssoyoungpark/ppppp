import axios from 'axios';
import React, { useEffect, useState } from 'react'
import BestItem from './BestItem';

const BestList = () => {
    const [products, setProducts] = useState();
    const callAPI = async() => {
        const result = await axios.get('/best/list');
        setProducts(result.data);
    }

    useEffect(()=>{
        callAPI();
    }, []);


    if(!products) return <h1>데이터를 불러오는중입니다...</h1>

    return (
        <div>
            <h1>Best Product List</h1>
            <table>
                <tbody>
                    <tr className='coo'>
                        <td></td>
                        <td width={100}>ID</td>
                        <td width={400}>Title</td>
                        <td width={150}>Category</td>
                        <td width={100}>Price</td>
                        <td width={100}>Show</td>
                    </tr>
                    {products.map(p=>
                        <tr key={p.id}>
                            <BestItem product={p}/>
                        </tr>    
                    )}
                </tbody>
            </table>
        </div>
    )
}

export default BestList