import React from 'react'

const BestItem = ({product}) => {
    const {id, title, linkImg, category, fprice, isShow} = product;
    return (
        <>
            <td><input type="checkbox"/></td>
            <td style={{textAlign:'center'}}>{id}</td>
            <td>
                <>
                    <span className='title'>{title}</span>
                </>
            </td>
            <td style={{textAlign:'center'}}>{category}</td>
            <td style={{textAlign:'center'}}>${fprice}</td>
            <td style={{textAlign:'center'}}>{isShow}</td>
        </>
        
    )
}

export default BestItem