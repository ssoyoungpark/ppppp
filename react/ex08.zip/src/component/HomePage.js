import React from 'react'
import SlickBest from './SlickBest'

const HomePage = () => {
    return (
        <div>
            <SlickBest/>
        </div>
    )
}

export default HomePage