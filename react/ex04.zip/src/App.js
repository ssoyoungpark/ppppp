import './App.css';
import RouterExample from './component/RouterExample';



const App = () => {
  return (
      <div className='App'>
        <RouterExample/>
      </div>
  );
}

export default App;
