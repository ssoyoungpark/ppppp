import React from 'react'
import { Link, Route, Routes } from 'react-router-dom'
import About from './About'
import Home from './Home'
import Profiles from './Profiles'

const RouterExample = () => {
    return (
        <div>
            <Link to="/">홈</Link>&nbsp;&nbsp;&nbsp;&nbsp;
            <Link to="/about?detail=false&id=lee">소개</Link>&nbsp;&nbsp;&nbsp;&nbsp;
            <Link to="/profiles">프로파일</Link>&nbsp;&nbsp;&nbsp;&nbsp;
            <hr/>
            <Routes>
                <Route path="/" element={<Home/>}/>
                <Route path="/about" element={<About/>}/>
                <Route path="/profiles/*" element={<Profiles/>}/>
            </Routes>
        </div>
    )
}

export default RouterExample