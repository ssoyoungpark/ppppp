import React, { useCallback, useState } from 'react'

const TodoInsert = ({onInsert, nextId}) => {
    const [text, setText] = useState('');

    const onChange = useCallback((e)=>{
        setText(e.target.value);
    },[])
    
    const onSubmit = (e) => {
        e.preventDefault();
        if(!window.confirm(`${nextId}번 할일을 등록하실래요?`)) return;
        onInsert(text);
        setText('');
    }
    return (
        <form onSubmit={onSubmit}>
            <input 
            onChange={onChange} 
            value={text} 
            placeholder='할일을 입력하세요'/>
            
            <button type='submit'>등록</button>
        </form>
    )
}

export default TodoInsert