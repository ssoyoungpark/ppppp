import React from 'react'

const Todoitem = ({todo, onDelete, onToggle}) => {
    const {id, text, checked} = todo;

    const styleChecked = {
        width:100
    }

    const onDeleteItem = ()=> {
        if(!window.confirm(`${id}번 할일을 삭제하실래요??`)) return;
        onDelete(id)
    }

    return (
        <div className={checked ? 'checked': ''}>
            <span style={styleChecked}>
                <input 
                    onClick={()=>onToggle(id)}
                    type="checkbox"
                    checked={checked}
                    readOnly/>
            </span>
            <span style={{width:'300px'}}>
                {id}:{text}
            </span>
            <button onClick={onDeleteItem}>삭제</button>
        </div>
    )
}

export default Todoitem