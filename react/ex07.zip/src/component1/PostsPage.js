import React from 'react'
import { Route, NavLink } from 'react-router-dom';
import Header from './Header';
import PostInsert from './PostInsert';
import PostList from './PostList';
import PostRead from './PostRead';
import PostUpdate from './PostUpdate';

const PostsPage = () => {
  const loginid=sessionStorage.getItem('loginid');
  return (
    <div>
          <Header/>
          <NavLink to="/posts/list" activeClassName='active'>
            Post List
          </NavLink>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <NavLink to={loginid ?"/posts/insert" :"/login?target=/posts/insert"} 
                activeClassName='active'>
            Post Insert
          </NavLink> :
          <hr/>
          <Route path="/posts/list" component={PostList} exact/>
          <Route path="/posts/insert" component={PostInsert}/>
          <Route path="/posts/read/:id" component={PostRead}/>
          <Route path="/posts/update/:id" component={PostUpdate}/>
    </div>
  )
}

export default PostsPage