import axios from 'axios';
import React, {useEffect, useState} from 'react'
import { Link, withRouter } from 'react-router-dom';

const PostRead = ({match, history}) => {
  const loginid=sessionStorage.getItem('loginid');
  const id=match.params.id;
  const [form, setForm] = useState({
    title:'',
    body:'',
    fdate:'',
    userid:''
  });

  const {title, body, fdate, userid} = form;
  const callAPI = async() => {
      const result=await axios.get(`/posts/${id}`);
      setForm(result.data);
  }

  useEffect(()=>{
    callAPI();
  },[]);

  if(title==='') return (
    <h1>데이터를 불러오는 중입니다...</h1>
  );

  return (
    <div>
      <div>
        <br/><br/><br/>
        <div>
          <span>{fdate} ({userid})</span>
        </div>
        <hr/><br/><br/>
        <div>{title}</div>
        <hr/><br/><br/>
        <div>{body}</div>
        <hr/>
        <div className='buttons'>
          {loginid === userid &&
            <Link to={`/posts/update/${id}`}>
              <button>수정</button>
            </Link>
          }
          <button onClick={()=>history.go(-1)}>목록</button>
        </div>
      </div>
    </div>
  )
}

export default withRouter(PostRead);