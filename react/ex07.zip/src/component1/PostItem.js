import React from 'react'
import { Link } from 'react-router-dom';

const PostItem = ({post, checkItems, onSingleCheck}) => {
  const {id, title, body, userid, fdate} = post;
  return (
    <div className='row'>
      <span className='chk'>
        <input type="checkbox"
          onChange={(e)=>{onSingleCheck(e.target.checked, id)}}
          checked={checkItems.includes(id) ? true:false}/>
      </span>
      <span className='pid'>{id}</span>
      <Link to={`/posts/read/${id}`}>
        <span className='title'>{title}</span>
      </Link>  
      <span className='userid'>{userid}</span>
      <span className='wdate'>{fdate}</span>
    </div>
  )
}

export default PostItem