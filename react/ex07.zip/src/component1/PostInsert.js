import axios from 'axios';
import React, { useRef, useState } from 'react'

const PostInsert = ({history}) => {
  const loginid = sessionStorage.getItem('loginid');
  const [form, setForm] = useState({
    title: '',
    body: '',
    userid: loginid
  });
  const {title, body, userid} = form;
  const refTitle = useRef();

  const onChange = (e) => {
    const newForm = {
      ...form,
      [e.target.name]:e.target.value
    }
    setForm(newForm);
  }

  const onSubmit = async(e) => {
    e.preventDefault();
    if(title==='') {
      alert('제목을 입력해주세요!');
      refTitle.current.focus();
      return;
    }
    //alert(JSON.stringify(form, null, 4));
    await axios.post('/posts/insert', form);
    history.push('/posts/list');
  }

  return (
    <div className='postInsert'>
      <form className='postForm' onSubmit={onSubmit}>
        <input value={title} ref={refTitle} onChange={onChange} 
              name="title" placeholder='제목을 입력하세요.'/>
        <textarea value={body} onChange={onChange}
              name="body" placeholder='내용을 입력하세요.'/>
        <div className='buttons'>
          <button type="submit">등록</button>
          <button type="reset">취소</button>
        </div>
      </form>
    </div>
  )
}

export default PostInsert;