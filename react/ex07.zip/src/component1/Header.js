import React from 'react'
import { useEffect,useState } from 'react';
import {Link, NavLink } from 'react-router-dom';

const Header = () => {
  const [loginid, setLoginid] = useState('');

  useEffect(()=>{
    console.log('........', loginid);
    setLoginid(sessionStorage.getItem('loginid'));
  });

  const onClickLogout = () => {
      sessionStorage.removeItem('loginid');
      setLoginid('');
  }

  return (
    <div>
      <NavLink to="/posts" activeClassName='active'>게시글</NavLink>
      &nbsp;&nbsp;&nbsp;&nbsp;
      <NavLink to="/users" activeClassName='active'>사용자</NavLink>
      <span style={{float:'right'}}>
        {loginid ? 
          <button onClick={onClickLogout}>{loginid} 로그아웃</button> : 
          <Link to="/login" ><button>로그인</button></Link>}
      </span> 
      <hr/>
    </div>
  )
}

export default Header