import React from 'react'
import { NavLink, Route } from 'react-router-dom'
import Header from './Header'
import UserList from './UserList'
import { UserRead } from './UserRead'

const UsersPage = () => {
  return (
    <div>
      <Header/>
      <NavLink to="/users/list" activeClassName='active'>
        User List
      </NavLink>
      <hr/>
      <Route path="/users/list" component={UserList}/> 
      <Route path="/users/read/:uid" component={UserRead}/>
    </div>
  )
}

export default UsersPage