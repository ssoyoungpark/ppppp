import axios from 'axios';
import React, { useEffect, useState } from 'react'

const BannerRead = ({match}) => {
  const id=match.params.id;
  const [banner, setBanner] = useState();
  
  const callAPI = async()=>{
    const result =await axios.get('/banner/read/' + id);
    setBanner(result.data);
  }

  useEffect(()=>{
    callAPI();
  },[]);

  if(!banner) return <h1>데이터를 불러오는 중입니다.</h1>
  return (
    <div>
      <h1>Banner Infomation</h1>
      <h3>{banner.title} : {banner.bshow===1? '진행중':'종료'}</h3>
      <img src={banner.url} style={{width:'90%'}}/>
    </div>
  )
}

export default BannerRead