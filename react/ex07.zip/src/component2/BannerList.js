import axios from 'axios';
import React, {useEffect, useState} from 'react'
import { Link } from 'react-router-dom';
import BannerItem from './BannerItem';

const BannerList = () => {
  const [items, setItems] = useState([]);
  const [banners, setBanners] = useState();

  const callAPI = async() => {
    const result=await axios.get('/banner/list');
    setBanners(result.data);
  }

  useEffect(()=>{
    callAPI();
  }, []);

  const onSingle= (id, checked) =>{
    if(checked){
      setItems(items.concat(id));
    }else{
      setItems(items.filter(item=>item !== id));
    }
  }

  const onAll =(checked) => {
    if(checked){
      const all=[];
      banners.forEach(banner=>all.push(banner.id));
      setItems(all);
    }else{
      setItems([]);
    }
  }

  const onClick = async(bshow) => {
    const message=bshow ===1 ? '보이기':'숨기기';

    if(items.length===0) {
      alert(`${message}할 아이템을 선택하세요!`);
      return;
    } 

    if(!window.confirm(`${items.length}개의 상태를 ${message}로 변경하실래요?`)) return;

    for(let i=0; i<items.length; i++){
      const data={bshow:bshow, id:items[i]};
      await axios.post('/banner/change', data);
    }
    callAPI();
    setItems([]);
  }

  const onDelete = async(id, url) => {
    if(!window.confirm(`${id}번\n${url}이미지 베너를 삭제하실래요?`)) return;
    //베너삭제
    await axios.post('/banner/delete',{id:id, url:url});
    callAPI();
  }

  if(!banners) return <h1>데이터를 불러오는 중입니다...</h1>
  return (
    <div>
      <h1>Banner List</h1>
      <div>
        <input type="checkbox" 
          onChange={(e)=>onAll(e.target.checked)}
          checked={items.length===banners.length && true}/>
        <button onClick={()=>onClick(1)}>보이기</button>
        <button onClick={()=>onClick(0)}>숨기기</button>
      </div>
      {banners.map(banner=>
        <BannerItem key={banner.id} 
          banner={banner} onSingle={onSingle}
          items={items}
          onDelete={onDelete}/>
      )}
    </div>
  )
}

export default BannerList