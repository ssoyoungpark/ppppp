import React, {useState, useEffect} from 'react'
import BannerList from './BannerList'
import BannerInsert from './BannerInsert'
import axios from 'axios'
import { Link, Route } from 'react-router-dom'
import BannerRead from './BannerRead'

const BannerPage = () => {
  return (
    <div>
      <div className='menu'>
        <Link to="/banner/list">Banner List</Link>
        <Link to="/banner/insert">Banner Resister</Link>
      </div>
      <hr/>
      <Route path="/banner/insert" component={BannerInsert}/>
      <Route path="/banner/list" component={BannerList}/>
      <Route path="/banner/read/:id" component={BannerRead}/>
    </div>
  )
}

export default BannerPage