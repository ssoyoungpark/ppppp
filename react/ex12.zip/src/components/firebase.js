import { initializeApp } from "firebase/app";
//import { getFirestore } from 'firebase/firestore';
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyB_vW4PgubNFxm1kEwn291_zAMmK88mDMw",
  authDomain: "fir-7ea02.firebaseapp.com",
  databaseURL: "https://fir-7ea02-default-rtdb.firebaseio.com",
  projectId: "fir-7ea02",
  storageBucket: "fir-7ea02.appspot.com",
  messagingSenderId: "910739164003",
  appId: "1:910739164003:web:2ac896e0f4528812926156",
  measurementId: "G-2B62L6F40F",
};

const app = initializeApp(firebaseConfig);
//export const db = getFirestore(app);
export const db = getDatabase(app);