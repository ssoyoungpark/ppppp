import React, { useState } from 'react'

const StudentInsert = ({onInsert}) => {
    const [form, setForm] =useState({
        name:'',
        tel:'010-',
        add:'인천시 남구 학익동'
    });

    const {name, tel, add} = form;
    const onChangeForm = (e) =>{
        const newForm={
            ...form,
            [e.target.name]:e.target.value
        }
        setForm(newForm);

    }

    const onInsertStudent = () =>{
        onInsert(form);
        setForm({
            name:'',
            tel:'010-',
            add:'인천시 남구 학익동'
        })
    }

  return (
    <div>
        <h1>학생등록</h1>
        <input name="name" onChange={onChangeForm} value={name} placeholder='이름'/><br/>
        <input name="tel" onChange={onChangeForm} value={tel} placeholder='전화'/><br/>
        <input name="add" onChange={onChangeForm} value={add} placeholder='주소'/><br/>
        <button onClick={onInsertStudent}>등록</button>
    </div>
  )
}

export default StudentInsert