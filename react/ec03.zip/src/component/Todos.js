import React, { useEffect, useState } from 'react'

const Todos = ({id, name}) => {
    const [todos, setTodos] = useState();
    const callAPI = () =>{
        fetch('https://jsonplaceholder.typicode.com/todos')
        .then(response => response.json())
        .then(json => {
            const newTodos=json.filter(todo=>todo.userId===id);
            setTodos(newTodos); 
        });
    }

    useEffect(()=>{
        callAPI();
    },[id]);

    if(!todos) return(
        <h1>데이터를 불러오는 중입니다....</h1>
    );

    return (
        <div>
            <h3>{name} Todo List</h3>
            {todos.map(t=><h5 key={t.id}>{t.title}</h5>)}
        </div>
    )
}

export default Todos