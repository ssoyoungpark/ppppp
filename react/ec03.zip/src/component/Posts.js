import React, { useEffect, useState } from 'react'

const Posts = ({id, name}) => {
    const [posts, setPosts] =useState();
    const callAPI = () => {
        fetch('https://jsonplaceholder.typicode.com/posts')
        .then(response => response.json())
        .then(json => {
            const newPosts=json.filter(post=>post.userId===id);
            setPosts(newPosts); 
        })
    }
    useEffect(()=>{
        callAPI();
    },[id]);

    if(!posts) return(
        <h1>데이터를 불러오는 중입니다...</h1>
    )

    return (
        <div>
            <h3>{name} Post List</h3>
            {posts.map(p=><h5 key={p.id}>{p.id}:{p.title}</h5>)}
        </div>
    )
}

export default Posts