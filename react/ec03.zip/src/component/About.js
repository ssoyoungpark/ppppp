import React from 'react'

const About = () => {
  return (
    <div>
        <h1>소개</h1>
        <p>프로젝트 소개 페이지입니다...</p>
    </div>
  )
}

export default About