import React from 'react'

const World = () => {
  return (
    <div>
        <h3>World</h3>
    </div>
  )
}

export default World