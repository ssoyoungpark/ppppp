import React, { useState } from 'react'

const Product = () => {
    const [products, setProducts] = useState([
        {code:'P101', title:'냉장고', price:3000000},
        {code:'P102', title:'세탁기', price:1500000},
        {code:'P103', title:'스타일러', price:1000000}
    ]);
    const [form, setForm] = useState({
        code: 'P104',
        title: '',
        price: 0
    });

    const {code, title, price} = form;

    const onChangeForm=(e)=>{
        const newForm={
            ...form,
            [e.target.name]:e.target.value
        }
        setForm(newForm);
    }

    const onClickInsert = () => {
        const newProducts=products.concat({
            code: code,
            title: title,
            price: price
        })
        setProducts(newProducts);
        setForm({
            code: 'p105',
            title: '',
            price: 0

        })
    }

    const onKeyDownPrice = (e) => {
        if(e.key==='Enter') onClickInsert();
    }


    const onDelete = (code) => {
        if(!window.confirm(`${code} 상품을 삭제하실래요?`)) return;
        const newProducts=products.filter(p=>code !== p.code);
        setProducts(newProducts);
    }
    return (
        <div>
            <h1>상품등록</h1>
            <div className='product'>
                <table width={650}>
                    <tr>
                        <td>상품코드: <input onChange={onChangeForm} value={code} type="text" name="code"/></td>
                    </tr>
                    <tr>
                        <td>상품이름: <input onChange={onChangeForm} value={title} type="text" name="title"/></td>
                    </tr>
                    <tr>
                        <td>상품가격: <input onKeyDown={onKeyDownPrice} onChange={onChangeForm} value={price} type="text" name="price"/></td>
                    </tr>
                    <tr>
                        <td><button onClick={onClickInsert}>상품등록</button></td>
                    </tr>
                </table>
            </div>

            <h1>상품목록</h1>
            <table>
                <tr className='title'>
                    <td width={100}>상품코드</td>
                    <td width={300}>상품이름</td>
                    <td width={100}>상품가격</td>
                    <td width={100}>상품삭제</td>
                </tr>
                {products.map(p => 
                    <tr className='row' key={p.code}>
                        <td>{p.code}</td>
                        <td>{p.title}</td>
                        <td>{p.price}</td>
                        <td><button onClick={()=>{onDelete(p.code)}}>상품삭제</button></td>
                    </tr>    
                )}
            </table>
        </div>
    )
}

export default Product