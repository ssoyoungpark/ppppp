import React from 'react'
import World from './World'

const Hello = () => {
  return (
    <div>
        <h1>Hello</h1>
        <World/>
    </div>
  )
}

export default Hello