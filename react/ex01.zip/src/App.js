import './App.css';
import PostList from './component/PostList';


const App = ()  =>{
    
    return (
        <div className="App">
            <PostList/>
        </div>
    );
}

export default App;
