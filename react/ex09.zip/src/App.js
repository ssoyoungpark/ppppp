import './App.css';
import './component/Pagination.css'
import { createTheme, ThemeProvider } from '@material-ui/core';
import { Route } from 'react-router-dom';

import CustomerChart from './component/CustomerChart';
import CustomerList from './component/CustomerList';
import MenuBar from './component/MenuBar';
import PostList from './component/PostList';
import PostRead from './component/PostRead';


const theme = createTheme({
    typography: {
        fontFamily: 'PyeongChang-Regular.ttf',
    }
})

function App() {
    return (
        <ThemeProvider theme={theme}>
            <div className="App">
                <Route path="/" component={MenuBar}/>
                <Route path="/customers" component={CustomerList}/>
                <Route path="/chart" component={CustomerChart}/>
                <Route path="/posts" component={PostList}/>
                <Route path="/posts/read/:id" component={PostRead}/>
            </div>
        </ThemeProvider>

    );
}
export default App;