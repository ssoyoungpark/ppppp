import React from 'react'
import { TableCell, TableRow } from '@material-ui/core';
import CustomerDelete from './CustomerDelete';
const CustomerItem = ({customer,callAPI}) => {
  
    const {id, name, image, gender, birthday, job, state } = customer;
    // tablerow=tr; tablecell=td
    return (
        <TableRow>
            <TableCell align="center">{id}</TableCell>
            <TableCell align="center" ><img src={image} alt='profile' width={50}/></TableCell>
            <TableCell align="center">{name}</TableCell>
            <TableCell align="center">{birthday}</TableCell>
            <TableCell align="center"><h1>{gender === '남' ? '🙋‍♂️' : '🙋‍♀️'}</h1></TableCell>
            <TableCell align="center">{job}</TableCell>
            <TableCell align="center"><CustomerDelete state={state} id={id} callAPI={callAPI}/></TableCell>
        </TableRow>
    )
}

export default CustomerItem
