import React from 'react'
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import { Link } from 'react-router-dom';




const PostItem = ({ post, callAPI }) => {

    const { id, userid, title, fdate } = post;

    return (

        <TableRow className='BB'>
            <TableHead>
                <TableCell align="center">{id}</TableCell>
                <TableCell align="center">{userid}</TableCell>

                <TableCell align="center">
                    <Link to="/posts/read" className='CC'>
                        {title}
                    </Link>
                </TableCell>


                <TableCell align="center">{fdate}</TableCell>
            </TableHead>
        </TableRow>

    )
}

export default PostItem