import Table from '@material-ui/core/Table';
import TableCell from '@material-ui/core/TableCell';
import TableBody from '@material-ui/core/TableBody';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';

import React, { useEffect, useState } from 'react'
import axios from 'axios';

const PostRead = ({post}) => {
    const {title, body, fdate, userid} = post;
    const [id, setId] = useState();
    const callAPI = async() => {
        const result=await axios.get(`/posts/${id}`);
        setId(result.data);
    }

    useEffect (()=>{
        callAPI();
    }, []);

    return (
        <div>
            <TableContainer>
                <Table>
                    <TableRow>
                        <TableCell>{title}</TableCell>
               
                        <TableCell>{body}</TableCell>
                    </TableRow>

                </Table>
            </TableContainer>
        </div>
    )
}

export default PostRead