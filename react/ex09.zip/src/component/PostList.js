import axios from 'axios';
import React, { useEffect, useState } from 'react'
import SearchAppBar from './SearchAppBar'
import Pagination from 'react-js-pagination';
import { CircularProgress } from '@material-ui/core';
import { makeStyles, ThemeProvider, createTheme } from '@material-ui/core/styles';

import Table from '@material-ui/core/Table';
import TableCell from '@material-ui/core/TableCell';
import TableBody from '@material-ui/core/TableBody';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Banner from './Banner';
import PostItem from './PostItem';

const theme = createTheme({
    typography: {
        fontFamily: 'PyeongChang-Regular.ttf',
    }
})

const useStyles = makeStyles({
    table: {
        minWidth: 80,
        textAlign: 'center'
    },
});

const PostList = () => {
    const classes = useStyles();
    const [posts, setPosts] = useState();

    const [page, setPage] = useState(1);
    const [word, setWord] = useState('');
    const [total, setTotal] = useState(0);

    const callAPI = async () => {
        const result = await axios.get(`/posts?page=${page}&word=${word}`);
        setPosts(result.data.list);
        setTotal(result.data.total);
    }

    useEffect(() => {
        callAPI();
    }, [page, word]);

    if (!posts) return <CircularProgress color="secondary" />

    return (
        <div>
            <Banner />
            <SearchAppBar setWord={setWord} setPage={setPage} />
            <ThemeProvider theme={theme}>
                <h1>Post List</h1>
                <span>검색수: {total}</span>
            </ThemeProvider>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell align="center" style={{ backgroundColor: "black", color: 'white', width: "1px" }}>번호</TableCell>
                            <TableCell align="center" style={{ backgroundColor: "black", color: 'white', width: "1px" }}>ID</TableCell>
                            <TableCell align="center" style={{ backgroundColor: "black", color: 'white', width: "100px" }}>제목</TableCell>
                            <TableCell align="center" style={{ backgroundColor: "black", color: 'white', width: "20px" }}>날짜</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {posts.map(p =>
                            <PostItem key={p.id} post={p} callAPI={callAPI} />
                        )}
                    </TableBody>
                </Table>
            </TableContainer>

            {total > 0 &&
                <Pagination
                    activePage={page}
                    itemsCountPerPage={10}
                    totalItemsCount={total}
                    pageRangeDisplayed={10}
                    prevPageText={"‹"}
                    nextPageText={"›"}
                    onChange={(e) => setPage(e)} />
            }
        </div>
    )
}

export default PostList