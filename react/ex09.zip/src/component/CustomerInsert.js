import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, FormControlLabel, FormLabel, Radio, RadioGroup, TextField } from '@material-ui/core';
import axios from 'axios';
import React, { useState } from 'react'


const CustomerInsert = ({ callAPI }) => {
    //다이얼로그 상자
    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    const [form, setForm] = useState({
        name: 'Rubies',
        birthday: '2000-10-04',
        gender: '여',
        job: '의사',
        file: null,
        fileName: ''
    });
    const { name, birthday, gender, job, file, fileName } = form;
    const onChange = (e) => {
        const newForm = {
            ...form,
            [e.target.name]: e.target.value
        }
        setForm(newForm);
    }
    const onChangeFile = (e) => {
        const newForm = {
            ...form,
            file: e.target.files[0],
            fileName: e.target.value
        }
        setForm(newForm);
    }
    const onSubmit = async (e) => {
        e.preventDefault();
        //alert(JSON.stringify(form, null, 4));
        if (!window.confirm('새로운 고객을 등록하실래요?')) return;
        const formData = new FormData();
        formData.append('image', file);
        formData.append('name', name);
        formData.append('gender', gender);
        formData.append('job', job);
        formData.append('birthday', birthday);
        const config = {
            Headers: { 'content-type': 'multipart/form-data' }
        };
        await axios.post('/customers/insert', formData, config);
        alert("새로운 고객이등록되었습니다.");
        callAPI();
        setForm({
            name: '',
            birthday: '',
            file: null,
            fileName: '',
            job: '',
            gender: ''
        })
        setOpen(false);
    }
    return (
        <div>
            <div>

                <Button variant="outlined" onClick={handleClickOpen}>고객 등록</Button>
                <Dialog
                    open={open}
                    onClose={handleClose}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description">
                    <DialogTitle id="alert-dialog-title">고객추가</DialogTitle>
                    <DialogContent>
                        <FormControl onSubmit={onSubmit}>
                            프로필이미지:
                            <input
                                onChange={onChangeFile}
                                value={fileName} type="file" name="file" /><br />
                            <Box
                                component="form"
                                sx={{ '& > :not(style)': { m: 1, width: '25ch', marginBottom:'10px'}, }}
                                noValidate
                                autoComplete="off" >
                                <TextField id="outlined-basic" label="이름" variant="outlined"
                                    onChange={onChange} value={name} type="text" name="name" />
                                <TextField id="outlined-basic" label="성별" variant="outlined"
                                    onChange={onChange} value={gender} type="text" name="gender" />
                                <TextField id="outlined-basic" label="직업" variant="outlined"
                                    onChange={onChange} value={job} type="text" name="job" />
                                <TextField id="outlined-basic" label="생년월일" variant="outlined"
                                    onChange={onChange} value={birthday} type="text" name="birthday" />
                            </Box>
                            {/* 생년월일:
                            <input
                                onChange={onChange}
                                value={birthday} type="date" name="birthday" /><br />
                            <FormLabel id="demo-radio-buttons-group-label">성별</FormLabel>
                            <RadioGroup
                                row
                                aria-labelledby="demo-radio-buttons-group-label"
                                defaultValue="여"
                                name="radio-buttons-group">
                                <FormControlLabel
                                    onChange={onChange}
                                    name="gender"
                                    checked={gender === '여' && true}
                                    value="여"
                                    control={<Radio />}
                                    label="여" />
                                <FormControlLabel
                                    onChange={onChange}
                                    name="gender"
                                    checked={gender === '남' && true}
                                    value="남"
                                    control={<Radio />}
                                    label="남" />
                            </RadioGroup>
                            직업:
                            <select name="job" value={job} onChange={onChange}>
                                <option>프로그래머</option>
                                <option>회사원</option>
                                <option>의사</option>
                                <option>변호사</option>
                                <option>기타</option>
                            </select><br /> */}
                        </FormControl>
                    </DialogContent>
                    <DialogActions>
                        <Button variant="contained" onClick={onSubmit}>등록</Button>
                        <Button variant="contained" onClick={handleClose} autoFocus>닫기</Button>
                    </DialogActions>
                </Dialog>
            </div>
        </div>
    )
}

export default CustomerInsert
