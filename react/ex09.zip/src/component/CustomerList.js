import React, { useEffect, useState } from 'react'
import CustomerItem from './CustomerItem'
import { makeStyles, ThemeProvider, createTheme } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import axios from 'axios';
import CustomerInsert from './CustomerInsert';
import { CircularProgress } from '@material-ui/core';
import Pagination from 'react-js-pagination';
import SearchAppBar from './SearchAppBar';
import Banner from './Banner';

const theme = createTheme({
    typography: {
        fontFamily: 'PyeongChang-Regular.ttf',
    }
})

const useStyles = makeStyles({
    table: {
        minWidth: 80,
        textAlign: 'center'
    },
});

const CustomerList = () => {
    const classes = useStyles();
    const [customers, setCustomers] = useState();

    const [page, setPage] = useState(1);
    const [total, setTotal] = useState(0);
    const [word, setWord] = useState();


    const callAPI = async (e) => {
        const response = await axios.get(`/customers/list?page=${page}&word=${word}`);
        setCustomers(response.data.list)
        setTotal(response.data.total);

    }

    useEffect(() => {
        console.log(`page:${page}`, `word:${word}`);
        callAPI('')
    }, [page, word])

    if (!customers) return <CircularProgress color="secondary" />

    return (
        <div>
            <SearchAppBar setWord={setWord} setPage={setPage} />
            <Banner />
            <CustomerInsert callAPI={callAPI} />
            <ThemeProvider theme={theme}>
                <h1>Customer List</h1>
            </ThemeProvider>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        
                        <TableRow>
                            <TableCell align="center" style={{ backgroundColor: "black", color: 'white' }}>번호</TableCell>
                            <TableCell align="center" style={{ backgroundColor: "black", color: 'white' }}>사진</TableCell>
                            <TableCell align="center" style={{ backgroundColor: "black", color: 'white' }}>이름</TableCell>
                            <TableCell align="center" style={{ backgroundColor: "black", color: 'white' }}>생년월일</TableCell>
                            <TableCell align="center" style={{ backgroundColor: "black", color: 'white' }}>성별</TableCell>
                            <TableCell align="center" style={{ backgroundColor: "black", color: 'white' }}>직업</TableCell>
                            <TableCell align="center" style={{ backgroundColor: "black", color: 'white' }}>삭제/복원</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {customers.map(c =>
                            <CustomerItem key={c.id} customer={c} callAPI={callAPI} />
                        )}
                    </TableBody>
                </Table>
            </TableContainer>
            {total > 0 ?
                <Pagination
                    activePage={page}
                    itemsCountPerPage={5}
                    totalItemsCount={total}
                    pageRangeDisplayed={10}
                    prevPageText={"‹"}
                    nextPageText={"›"}
                    onChange={(e) => setPage(e)} />
                : <TableContainer>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell colSpan="7" align="center" style={{ backgroundColor: "black", color: 'white' }}>검색 결과가 없습니다</TableCell>
                            </TableRow>
                        </TableHead>
                    </Table>
                </TableContainer>
            }
        </div>

    )
}

export default CustomerList