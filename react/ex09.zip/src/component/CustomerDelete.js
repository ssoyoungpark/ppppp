import React, { useState } from 'react'
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Typography } from "@material-ui/core";
import axios from 'axios';

const CustomerDelete = ({ state, id, callAPI }) => {
    const [open, setOpen] = useState(false);
    const onClickOpen = () => {
        setOpen(true);
    }
    const onClickClose = () => {
        setOpen(false);
    }
    const onChange = async() => {
        const change=state==='1' ? '0' : '1'
        await axios.post(`/customers/change` ,{id:id, state :change })
        callAPI();
        setOpen(false);
    }
    return (
        <>
            {state === '0' ?
                <Button variant='contained' color='primary' onClick={onClickOpen}>RECOVER</Button> :
                <Button variant='contained' color='secondary' onClick={onClickOpen}>DELETE</Button>
            }
            <Dialog open={open}>
                <DialogTitle>{state==='1'? '복원': '삭제'}</DialogTitle>
                <DialogContent gutterBottom>
                    <Typography>
                        {state==='1' ? '선택한 정보를 삭제 하시겠습니까?' : '선택한 정보를 복원 하시겠습니까?'}
                    </Typography>
                </DialogContent>
                <DialogActions>
                    <Button variant="contained" color='primary' onClick={onChange}>
                        {state === '1' ? 'DELETE' : 'RECOVER'}
                    </Button>
                    <Button variant="outlined" onClick={onClickClose}>닫기</Button>
                </DialogActions>
            </Dialog>
        </>
    )
}
export default CustomerDelete
