import React, { useEffect, useState } from 'react'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import "./Carousel.css"
import { ArrowBackIos, ArrowForwardIos } from '@material-ui/icons';

const data=[
  {id:1 , url:'https://picsum.photos/seed/1/900/250'},
  {id:2 , url:'https://picsum.photos/seed/2/900/250'},
  {id:3 , url:'https://picsum.photos/seed/3/900/250'},
  {id:4 , url:'https://picsum.photos/seed/4/900/250'},
  {id:5 , url:'https://picsum.photos/seed/5/900/250'},
]

function SampleNextArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div className={className} onClick={onClick}>
        <ArrowForwardIos style={{color:'black', fontSize:'30'}}/>
    </div>
  );
}

function SamplePrevArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div
        className={className} onClick={onClick}>
        <ArrowBackIos style={{color:'black', fontSize:'30'}}/>
    </div>
  );
}

const Banner = () => {
  const settings = {
    dots: true,
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    nextArrow: <SampleNextArrow />,
    prevArrow: <SamplePrevArrow />
  };

  const [banners, setBanners] = useState();
  
  useEffect(()=>{
    setBanners(data);
  },[]);
  
  if(!banners) return <h1>데이터를 불러오는 중입니다...</h1>
  return (
    <Slider {...settings}>
      {banners.map(b=>
        <img key={b.url} src={b.url} alt={b.url}/>
      )}
    </Slider>
  )
}

export default Banner