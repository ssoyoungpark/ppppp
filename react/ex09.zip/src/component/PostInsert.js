import React from 'react'

import Table from '@material-ui/core/Table';
import TableCell from '@material-ui/core/TableCell';
import TableBody from '@material-ui/core/TableBody';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import CustomerInsert from './CustomerInsert';
import Paper from '@material-ui/core/Paper';

const PostInsert = ({ match }) => {
    const { title, body, userid } = form;
    const id = match.params.id;

    return (
        <div>
            <TableContainer>
            
                <Table>
                    <TableHead>
                    <TableRow>
                        <input value={title} ref={refTitle} onChange={onChange} name="title" placeholder='제목을 입력하세요.' />
                        <textarea value={body} onChange={onChange} name="body" placeholder='내용을 입력하세요.' />
                    </TableRow>

                </TableHead>
                </Table>
                
            </TableContainer>

        </div>
    )
}

export default PostInsert