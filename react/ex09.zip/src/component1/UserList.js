import React, { useEffect, useState } from 'react'
import { withRouter } from 'react-router-dom'
import UserList from './UserList'
import qs from 'qs';
import axios from 'axios';
import { Table } from '@material-ui/core';

const UserPage = ({history, location}) => {
    const search=qs.parse(location.search, {ignoreQueryPrefix:true});
    const searchWord=!search.word ? '': search.word;
    const page=!search.page ? 1: parseInt(search.page);

    const [list, setList] = useState();
    const [total, setTotal] = useState(0);
    const [word, setWord] = useState(searchWord);

    const callAPI = async()=> {
        const result = await axios.get(`/user/list?word=${searchWord}&page=${page}`)
        setList(result.data.list);
        setTotal(result.data.total);
    }
    const onChangePage = (e) => {
        history.push(`/user/list?page=${e}&word=${searchWord}`);
    }
    const onKeyDown = (e) => {
        if(e.keyCode === 13){
            history.push(`/user/list?page=1&word=${e.target.value}`);
        }
    }

    useEffect(()=>{
        setWord(searchWord);
        callAPI();

    }, [location]);

    if(!list) return <h1>Loading...</h1>

  return (
    <div>
        <imput placeholder='검색어'
            value={word} 
            onChange={(e)=>setWord(e.target.value)}
            onKeyDown={onKeyDown}/>
        <Table>
            <tdody>
                {list.map(user=>
                    <tr key={user.uid}>
                        <td>{user.uid}</td>
                        <td>{user.uname}</td>
                    </tr>
                )}
            </tdody>
        </Table>
    </div>
  )
}

export default withRouter(UserList)