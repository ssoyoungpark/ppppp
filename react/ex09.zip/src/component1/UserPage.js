import React from 'react'
import UserList from './UserList'

const UserPage = () => {
  return (
    <div>
        <UserList/>
    </div>
  )
}

export default UserPage