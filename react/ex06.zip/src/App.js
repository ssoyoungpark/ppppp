import { useEffect, useState } from 'react';
import { Link, NavLink, Route } from 'react-router-dom';
import './App.css';
import Header from './component/Header';
import Home from './component/Home';
import LoginPage from './component/LoginPage';
import PostsPage from './component/PostsPage';
import UsersPage from './component/UsersPage';



function App() {
    

    return (
        <div className="App">
            <Route path="/" component={Home} exact/>
            <Route path="/posts" component={PostsPage}/>
            <Route path="/users" component={UsersPage}/>
            <Route path="/login" component={LoginPage}/>
        </div>
    );
}

export default App;
