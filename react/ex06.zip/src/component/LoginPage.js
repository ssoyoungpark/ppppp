import axios from 'axios';
import React, { useState } from 'react'
import Header from './Header';
import qs from 'qs';

const LoginPage = ({history, location}) => {
    const search = qs.parse(location.search,{ignoreQueryPrefix:true});
    const target = search.target;

    const [user, setUser] = useState({
        uid:'',
        upass:'',
    });
    const {uid, upass} = user;
    const [message, setMessage] = useState('');
    const onChangeUser= (e) => {
        const newUser={
            ...user,
            [e.target.name]:e.target.value
        }
        setUser(newUser);
        console.log('upass', upass);
    }

    const onSubmit = async(e) => {
        e.preventDefault();
        const data={uid:uid, upass:upass};
        const result=await axios.post('/users/login',data);
        if(!result.data.uid) {
            setMessage('아이디가 존재하지 않습니다.');
        }else if(result.data.upass !== upass) {
            setMessage('비밀번호가 일치하지 않습니다.');
        }else{
            alert('로그인 성공')
            sessionStorage.setItem('loginid', uid);
            if(target){
                history.push(target);
            }else{
                history.push('/');
            }
        }
    }

    const style={
        width:300, margin:'0px auto'
    }

    return (
        <div>
            <Header/>
            <h1>로그인</h1>
            <form style={style} onSubmit={onSubmit}>
                <div>
                    <input name="uid" onChange={onChangeUser}
                        value={uid} placeholder='아이디'/>
                </div>
                <div>
                    <input name="upass" onChange={onChangeUser} 
                        value={upass} type='password' placeholder='비밀번호'/>
                </div>
                <div className='buttons'>
                    <button>로그인</button>
                </div>
            </form>
            <div style={{background:'red', color:'white'}}>
                <h3>{message && message}</h3>
            </div>
        </div>
    )
}

export default LoginPage