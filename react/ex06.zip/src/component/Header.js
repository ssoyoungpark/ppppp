import React from 'react'
import { useEffect, useState } from 'react';
import { Link, NavLink} from 'react-router-dom';


const Header = () => {

    const [loginid, setLoginid] = useState('');

    useEffect(()=>{
        setLoginid(sessionStorage.getItem('loginid'));
        
    }, [loginid]);

    const onClickLogout = () => {
        sessionStorage.removeItem('loginid');
        setLoginid('');
    }


    return (
        <div>
            <NavLink to="/posts" activeclassName='active1' >게시글</NavLink>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <NavLink to="/users" activeclassName='active1'>사용자</NavLink>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <span style={{float:'right'}} activeclassName='active1'>
                {loginid ? <button onClick={onClickLogout}>{loginid}로그아웃</button> : 
                <NavLink to="/login"><button>로그인</button></NavLink>}
            </span>
            <hr/>
        </div>
    )
}

export default Header