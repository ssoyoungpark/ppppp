import axios from 'axios';
import React, { useEffect, useState } from 'react'

const UserRead = ({match}) => {
    const [user, setUser] = useState({
        uid:'',
        uname:'',
        address:'',
        tel:'',
        status:''
    });

    const uid=match.params.uid;
    const {uname, status, address, tel} = user;


    const callAPI = async() => {
        const result = await axios.get(`/users/read/${uid}`);
        setUser(result.data);
    }


    const onClickStatus = async() => {
        if(!window.confirm(`${uid} 회원의 상태를 ${status}로 변경하실래요?`)) return;
        const data = {uid:uid, status:status}
        await axios.post('/users/change', data);
        callAPI();
    }

    const onChange = (e) => {
        const newUser = {
            ...user,
            status: e.target.value()
        }
        setUser(newUser);
    }

    useEffect (()=>{
        callAPI();
    },[]);

    if(!user) return (<h1>데이터를 불러오는 중입니다!</h1>)


    return (
        <div>
            <h3>{uid} ({uname})</h3>
            <h3>
                등급:&nbsp;&nbsp;&nbsp;
                <select onChange={(e)=>onChange}>
                    <option value='green' selected={status==='green' && true}>일반</option>
                    <option value='black' selected={status==='black' && true}>우수</option>
                    <option value='gold' selected={status==='gold' && true}>VIP</option>
                    <option value='purple' selected={status==='purple' && true}>VVIP</option>
                </select>
                <button 
                    style={{background:status}}
                    onClick={onClickStatus}>등급변경</button>
                </h3>
                <h3>주소:{address ? address: '주소가 등록되지 않았습니다.'}</h3>
                <h3>전화{tel ? tel: '전화번호가 등록되지 않았습니다.'}</h3>
        </div>
    )
}

export default UserRead