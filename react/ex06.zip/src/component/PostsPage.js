import React from 'react'
import { NavLink, Route } from 'react-router-dom';
import PostInsert from './PostInsert';
import PostRead from './PostRead';
import PostUpdate from './PostUpdate';
import PostList from './PostList';
import Header from './Header';


const PostsPage = () => {
    const loginid =sessionStorage.getItem('loginid');

    return (
        <div>
            <Header/>
            <NavLink activeclassName='link1' to="/posts/list">Post List</NavLink>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

            <NavLink activeclassName='link1' to={loginid ? "/posts/insert" : "/login?target=/posts/insert"}>Post Insert</NavLink>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <hr/>
        
            <Route path="/posts/list" component={PostList} exact/>
            <Route path="/posts/insert" component={PostInsert}/>
            <Route path="/posts/read/:id" component={PostRead}/>
            <Route path="/posts/update/:id" component={PostUpdate}/>
        </div>
    )
}

export default PostsPage