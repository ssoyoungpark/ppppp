import React, { useEffect, useRef, useState } from 'react'
import axios from 'axios';
import { withRouter } from 'react-router-dom';

const PostUpdate = ({match, history}) => {

    const id=match.params.id;
    const [form, setForm] =useState({
        id: id,
        title:'',
        body:'',
    })

    const {title, body} = form;
    const refTitle = useRef();
    const onChange = (e) => {
        const newForm = {
            ...form,
            [e.target.name]:e.target.value
        }
        setForm(newForm);
    }

    const onSubmit = async(e) => {
        e.preventDefault();
        if(title==='') {
            alert('제목을 입력해주세요!');
            refTitle.current.focus();
            return;
        }

        //alert(JSON.stringify(form,null,4));
        if(!window.confirm(`${id}번 게시글을 수정하실래요?`)) return;
        await axios.post('/posts/update', form);
        alert('수정되었습니다.')
        history.go(-2);
    }

    const callAPI = async() => {
        const result=await axios.get(`/posts/${id}`);
        setForm(result.data);
    }

    const onClickDelete = async() => {
        if(!window.confirm(`${id}번 게시글을 삭제하실래요?`)) return;
        await axios.post(`/posts/delete/${id}`);
        alert('삭제되었습니다.')
        history.go(-2);
    }

    useEffect(()=>{
        callAPI();
    }, []);


    useEffect (()=>{
        const message = history.block('정말로 뒤로 가실래요?');
        return () => {
            if(message) message();
        }
    }, [history]);

    
    if(title==='') return(
        <div>데이터를 불러오는 중입니다...</div>
    );

    return (
        <div className='postInsert'>
            <form className='postForm' onSubmit={onSubmit}>
                <input value={title} 
                    ref={refTitle} 
                    onChange={onChange} 
                    name="title" 
                    placeholder='제목을 입력하세요.'/>

                <textarea value={body} 
                    onChange={onChange} 
                    name="body" 
                    placeholder='내용을 입력하세요.'/>

                <div className='buttons'>
                    <button type="submit">저장</button>
                    <button type="button" onClick={onClickDelete}>삭제</button>
                    <button type="reset">취소</button>
                </div>
            </form>
        </div>
    )
}

export default withRouter(PostUpdate);