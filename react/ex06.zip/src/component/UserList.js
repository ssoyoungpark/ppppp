import axios from 'axios';
import React, { useEffect, useState } from 'react'
import UserItem from './UserItem';
import qs from 'qs';
import { Link } from 'react-router-dom';

const UserList = ({location}) => {
    const search = qs.parse(location.search, {ignoreQueryPrefix:true});
    const page = !search.page ? 1 : parseInt(search.page);


    const [users, setUsers] = useState();
    const [total, setTotal] = useState(0);
    const [last, setLast] = useState(1);
    const [word, setWord] = useState('');
    const [items, setItems] = useState([]);
    const [status, setStatus] = useState('');

    const callAPI = async() => {
        console.log('..........',page,word);
        const result = await axios.get(`/users/list?page=${page}&word=${word}`);
        setUsers(result.data.list);
        setTotal(result.data.total);
        setLast(Math.ceil(result.data.total/5));
        console.log('.........',users);
    }

    useEffect(()=>{
        callAPI();
    }, [page, word]);

    if(!users) return(
        <h1>데이터를 불러오는 중입니다...</h1>
    )

    const onSingleCheck = (checked, uid) => {
        if(checked){
            setItems(items.concat(uid));
        }else{
            setItems(items.filter(item=> item !==uid));
        }
    }

    const onAllcheck = (checked) => {
        if(checked) {
            const all=[];
            users.forEach(user=>all.push(user.uid));
            setItems(all);
        }else{
            setItems([]);
        }
    }

    const onClickBlack = () => {
        if(items.length === 0){
            alert('신고할 User를 선택하세요!');
            return;
        }

        
        if(!window.confirm(`${items.length}명의 User를 ${status}로 변경하실래요?`)) return;
        items.forEach(async(item)=> {
            const data={uid:item, status:status}
            await axios.post('/users/change', data);
       });
       callAPI();
       setItems([]);
    }

    return (
        <div>
            <div className='condition'>
                <div className='left'>
                    <input type="checkbox" 
                        onChange={(e)=>onAllcheck(e.target.checked)}
                        checked={items.length===users.length && true}/>
                    <select onChange={(e)=>setStatus(e.target.value)}>
                        <option value='green'>일반</option>
                        <option value='black'>우수</option>
                        <option value='gold'>VIP</option>
                        <option value='purple'>VVIP</option>
                    </select>
                    <button onClick={onClickBlack}>신고</button>
                    
                </div>
                <div className='right'>
                    <input placeholder='검색어'
                        onChange={(e)=>setWord(e.target.value)}/>&nbsp;&nbsp;&nbsp;
                    <span><b>{total}명</b></span>
                </div>
                <br/>
            </div>

            {users.map(user=>
                <div key={user.uid}>
                    <UserItem user={user}
                        items={items}
                        onSingleCheck={onSingleCheck}/>
                </div>  
            )}
            <div className='buttons'>
                <Link to={`/users/list?page=${page-1}`}>
                    <button disabled={page===1 && true}>이전</button>
                </Link>
                <span> {page} / {last} </span>
                <Link to={`/users/list?page=${page+1}`}>
                    <button disabled={page===last && true}>다음</button>
                </Link>
            </div>
        </div>
    )
}

export default UserList