import React from 'react'
import Button from 'react-bootstrap/Button';

const SendItem = ({msg}) => {
  const {mid, receiver, uname, sendDate, readDate} = msg
  return (
    <tr>
      <td>{mid}</td>
      <td>{uname} ({receiver})</td>
      <td>{sendDate}</td>
      <td>{readDate ? readDate: '안읽음'}</td>
      <td><Button>보기</Button></td>
    </tr>
  )
}

export default SendItem