import axios from 'axios';
import React, { useEffect, useState } from 'react'
import ReplyInsert from './ReplyInsert';
import ReplyItem from './ReplyItem';
import './Paging.css';
import Pagination from "react-js-pagination";

const RplyList = ({bno, setReplycnt}) => {
  const [list, setList] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);

  const callAPI = async() => {
    const result = await axios.get(`/api/reply/list/${bno}?page=${page}`);
    setList(result.data.list);
    setReplycnt(result.data.total);
    setTotal(result.data.total);
  }

  useEffect(()=>{
    callAPI();
  } ,[page]);

  if(!list) return <h1>Loading......</h1>
  
  return (
    <div>
      <h3>Reply List</h3>
      <ReplyInsert bno={bno} callAPI={callAPI}/>
      <table>
        <tbody>
          {list.map(reply=>
            <ReplyItem 
              key={reply.rno} 
              reply={reply} callAPI={callAPI}/>
          )}
        </tbody>
      </table>
      <Pagination
            activePage={page}
            itemsCountPerPage={10}
            totalItemsCount={total}
            pageRangeDisplayed={10}
            prevPageText={"‹"}
            nextPageText={"›"}
            onChange={(e)=>setPage(e)}/>
    </div>
  )
}

export default RplyList