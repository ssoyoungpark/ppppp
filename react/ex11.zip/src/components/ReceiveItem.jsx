import axios from 'axios';
import React, {useContext, useState} from 'react'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { UserContext } from '../context/UserContext';

const ReceiveItem = ({msg, callAPI, setUser}) => {
  const {callAPIUser} = useContext(UserContext);
  
  const [message, setMessage] = useState('');
  const {mid, sender, uname, readDate, sendDate} = msg
  const [show, setShow] = useState(false);
  
  const handleClose = async() => {
    setShow(false);
    callAPI();
    callAPIUser();
  }

  const onClickView = async() => {
    const result=await axios.get(`/api/message/read/${mid}`);
    setMessage(result.data.message);
    setShow(true);
  }

  return (
    <>
      <tr style={{color: !readDate && 'gray'}}>
          <td>{mid}</td>
          <td>{uname} ({sender})</td>
          <td>{sendDate}</td>
          <td>{readDate}</td>
          <td><Button variant="primary" onClick={onClickView}>보기</Button></td>
      </tr>
      <Modal show={show} onHide={handleClose} animation={false}>
        <Modal.Header closeButton>
          <Modal.Title>메시지확인</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {message}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            확인
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default ReceiveItem