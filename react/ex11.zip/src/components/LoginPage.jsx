import React, { useState } from 'react'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Card from 'react-bootstrap/Card';
import Alert from 'react-bootstrap/Alert';
import axios from 'axios';
import HeaderPage from './HeaderPage';

const LoginPage = ({history}) => {
  const [message, setMessage] = useState('');
  const [form, setForm] = useState({
    uid: '',
    upass: ''
  });
  const {uid, upass} = form;

  const onSumbmit = async(e) => {
    e.preventDefault();
    const result=await axios.get('/api/user/read/' + uid);
    if(!result.data){
      setMessage('해당 아이디가 존재하지 않습니다.')
    }else if(result.data.upass !== upass){
      setMessage('비밀번호가 일치하지 않습니다.');
    }else{
      setMessage('');
      sessionStorage.setItem("uid", uid);
      history.push('/');
    }
  }

  const onChange = (e) => {
    setForm({
      ...form,
      [e.target.name]:e.target.value
    })
  }

  return (
    <>
      <HeaderPage/>
      <Card style={{width:'50%'}}>
        <Form className="p-3" onSubmit={onSumbmit}>
          <Form.Control className="my-3"
            value={uid}
            name="uid"
            onChange={onChange}
            placeholder='User id'/>
          <Form.Control className="my-3"
            value={upass}
            name="upass"
            type="password"
            onChange={onChange}
            placeholder='Password'/>
          <Button type="submit">로그인</Button>
        </Form>

        {message &&
          <Alert key="primary" variant="primary" className='m-3'>
              {message}
          </Alert>
        }
      </Card>
    </>
  )
}

export default LoginPage