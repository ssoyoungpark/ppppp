import React from 'react'
import { Link, withRouter } from 'react-router-dom';

const HeaderPage = ({history}) => {
  const onClickLogout = (e) => {
      e.preventDefault();
      sessionStorage.removeItem('uid');
      history.push('/');
  }
  return (
    <div>
      <div className='main_menu'>
        <Link to="/">홈</Link>
        <Link to="/board/list">게시판관리</Link>
        {sessionStorage.getItem('uid') ? 
          <>
            <Link to="/message">메시지함</Link>
            <a onClick={onClickLogout} 
              href="#" style={{float:'right'}}>
              로그아웃 
            </a>
            <span style={{float:'right', fontSize:'1.5rem', paddingRight:20, color:'red'}}>
              {sessionStorage.getItem('uid')}
            </span>
          </>
          :
          <Link to="/login" style={{float:'right'}}>로그인</Link>
        }
      </div>
      <hr/>
    </div>
  )
}

export default withRouter(HeaderPage)