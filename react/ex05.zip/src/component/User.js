import React from 'react'
import { NavLink, Route } from 'react-router-dom';
import Todos from './Todos';

const User = ({user}) => {
    const {id, name, username, email} = user;
    
    const style = {background:'aqua', color:'white'};

    return (
        <div>
            <ul>
                <li>
                    <NavLink to={`/users/${id}`} activeStyle={style}>
                        {id} {name}({username})
                    </NavLink>
                </li>
            </ul>
        </div>
    )
}

export default User