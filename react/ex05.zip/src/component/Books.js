import axios from 'axios';
import React, { useEffect, useState } from 'react'
import Book from './Book';
import './Book.css';
import qs from 'qs';

const Books = ({location, page}) => {
    const search = qs.parse(
        location.search, {ignoreQueryPrefix:true}
    );
    const query=search.title;

    const [books, setBooks] = useState();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(false);

    const callAPI = async() => {
        try{
            setLoading(true);
            const url=`https://dapi.kakao.com/v3/search/book?target=title&size=5&query=${query}&page=${page}`
            const config = {
                headers:{"Authorization": "KakaoAK cc9f6deed893b92120a559aaadc8c992"}
            }
            const res=await axios.get(url, config);
            setBooks(res.data.documents);
            setLoading(false);
        }catch(e){
            setLoading(false);
            setError(e.message);

        }
    }

    useEffect(()=>{
        callAPI();
    },[query]);

    useEffect(()=>{
        callAPI();
    },[page]);

    if(loading) return (
        <h1>로딩중입니다....</h1>
    );

    if(!books) return (
        <h1>에러발생: {error}</h1>
    );

    return (
        <div className='books'>
            {books.map(book=> <Book key={book.isbn} book={book}/>)}
        <div><span>더보기</span></div>
        </div>
    )
}

export default Books