import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import './Category.css';

const categories =[
    {id:1, title:'자바'}, 
    {id:2, title:'HTML5'}, 
    {id:3, title:'Node.js'}, 
    {id:4, title:'Serblet'}, 
    {id:5, title:'안드로이드'}, 
    {id:6, title:'스프링'}, 
    {id:7, title:'데이터베이스'},
    {id:8, title:"리액트"}
]
const Categories = () => {
    return (
        <div className='categories'>
            {categories.map(c=>
                <span className='category' key={c.id}>
                    <Link to={`/?title=${c.title}&page=${page}`}>{c.title}</Link>
                </span>
            )}
        </div>
    )
}

export default Categories