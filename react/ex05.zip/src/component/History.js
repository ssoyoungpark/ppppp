import React, { useEffect } from 'react'

const History = ( {history} ) => {
    useEffect(()=>{
        const unblock=history.block('정말 떠나실건가요?');

        return ()=>{
            unblock();
        }
    }, [history]);

    return (
        <div>
            <button onClick={()=>history.goBack()}>뒤로</button>
            <button onClick={()=>history.push('/about1')}>소개로</button>
        </div>
    )
}

export default History