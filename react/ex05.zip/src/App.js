import './App.css';
import APIExample from './component3/APIExample';



function App() {
  


    return (
      <div className="App">
        <APIExample/>
      </div>
    );
}

export default App;
