import React from 'react'

const MovieList = () => {
    return (
        <div>MovieList</div>
    )
}

export default MovieList