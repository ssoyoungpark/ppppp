import React from 'react'
import Parser from 'html-react-parser';
import { Link } from 'react-router-dom';

const ProductItem = ({product}) => {
    const {title, link, image, lprice, url} = product;
    const price=lprice.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

    const style = {
        width: 250
    }
    
    return (
        <div className="newsItemBlock">
            <div className="thumbnail">
                <a href={link} target='_blank'>
                <img style={style} src={image} alt="thumbnail"/>
                </a>
            </div>
            <br/>
            <div className="contents">
                <br/>
                <a href={link} target='_blank'>{Parser(title)}</a>
                <br/>
                <p>가격: {price}원</p>
                <br/>
                <a href={link} target='_blank'>
                    <button>구매하기</button>
                </a>
            </div>
        </div>
        
    )
}

export default ProductItem