import React from 'react'

const BookItem = ({book}) => {
    return (
        <div>
            <a href={book.url}>
            <h4>{book.title}</h4>
            </a>
        </div>
    )
}

export default BookItem