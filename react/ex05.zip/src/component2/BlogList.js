import React, { useEffect, useState } from 'react'
import qs from 'qs';
import axios from 'axios';
import BlogItem from './BlogItem';
import { Link } from 'react-router-dom';
import Parser from 'html-react-parser';

const BlogList = ({match, location}) => {
    const title=match.params.title;
    const search=qs.parse(
        location.search, {ignoreQueryPrefix:true}
    );
    const page=parseInt(search.page);

    const [blogs, setBlogs] = useState();
    const [is_end, setIs_end] = useState(false);

    const callAPI= async() => {
        const url=`https://dapi.kakao.com/v2/search/blog?target=title&size=5&query=${title}&page=${page}`;
        const config={
            headers: {'Authorization': 'KakaoAK cc9f6deed893b92120a559aaadc8c992'}
        };
        const result=await axios.get(url, config);
        const documents=result.data.documents
        const newBlogs= page===1 ? documents:blogs.concat(documents);
        setBlogs(newBlogs);
        setIs_end(result.data.meta.is_end);
    }

    useEffect(()=>{
        callAPI();
    }, [title,page]);

    if(!blogs) return(
        <h1>데이터를 불러오는 중입니다...</h1>
    );


    return (
        <div>
            {blogs.map(b =>
                <BlogItem key={b.isbn} blog={b}/>    
            )}
            {!is_end && <Link to={`/blog/${title}?page=${page+1}`}>더보기</Link>} 
        
        </div>
    )
}

export default BlogList