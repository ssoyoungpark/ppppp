import React from 'react'
import { Route } from 'react-router-dom'
import BlogList from './BlogList'
import Categories from './Categories'

const BlogPage = () => {
    const string='<h3>블로그검색</h3>'
    return (
        <div>
            <Categories/>
            <hr/>
            <Route path="/blog/:title" component={BlogList} exact/>
        </div>
    )
}

export default BlogPage