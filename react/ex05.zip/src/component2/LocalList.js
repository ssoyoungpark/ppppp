import React, { useEffect, useState } from 'react'
import axios from 'axios';
import LocalItem from './LocalItem';
import qs from 'qs';
import { Link, Route, withRouter } from 'react-router-dom';
import Map from './Map';


const LocalList = ({location}) => {
    const [locals, setLocals] = useState();
    const [is_end, setIs_end] = useState(false);

    const search = qs.parse (
        location.search, {ignoreQueryPrefix:true}
    );
    const page = parseInt(search.page);
    const query = search.query;

    const callAPI = async() => {
        const url=`https://dapi.kakao.com/v2/local/search/keyword.json?size=5&query=${query}&page=${page}`;
        const config={
            headers: {'Authorization':'KakaoAK cc9f6deed893b92120a559aaadc8c992'}
        };
        const result = await axios.get(url, config);
        const documents = result.data.documents;
        setIs_end(result.data.meta.is_end);

        const newLocals = page===1? documents : locals.concat(documents);
        setLocals(newLocals);
    }

    
    useEffect(()=>{
        callAPI();
    },[query, page]);

    if(!locals) return (
        <h1>데이터를 불러오는 중입니다.</h1>
    );

    return (
        <div>
            <Route path="/local/map" component={ Map } />
            
            {locals.map(local=> 
                <LocalItem key={local.id} local={local}/>
            )}
            
            {!is_end && 
                <Link to={`/local?query=${query}&page=${page+1}`}>
                    <span>더보기</span>
                </Link>}
        </div>
        
    )
}

export default withRouter( LocalList );