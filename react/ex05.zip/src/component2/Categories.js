import React from 'react'
import { NavLink, withRouter } from 'react-router-dom'

const categories = [
    {id:1, title:'바른생활'},
    {id:2, title:'HTML5'},
    {id:3, title:'Node.js'},
    {id:4, title:'JSP와 Servlet'},
    {id:5, title:'안드로이드'},
    {id:6, title:'React'},
    {id:7, title:'스프링'},
    {id:8, title:'데이터베이스'},
]

const Categories = ({match}) => {
    const path=match.path;
    
    const style={
        padding:'20px 10px'
    }

    const activeStyle={
        background:'gray',
        color:'white'
    }
    return (
        <div>
            {categories.map(c=>
            <NavLink to={`${path}/${c.title}?page=1`} 
                key={c.id} 
                activeStyle={activeStyle}>
                <span style={style}>{c.title}</span>
            </NavLink>
            )}
        </div>
    )
}

export default withRouter(Categories)