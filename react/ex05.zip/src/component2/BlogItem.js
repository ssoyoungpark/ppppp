import React from 'react'
import Parser from 'html-react-parser';

const BlogItem = ({blog}) => {
    return (
        <div>
            <a href={blog.url}>
            <h4>{Parser(blog.title)}</h4>
            </a>
        </div>
    )
}

export default BlogItem