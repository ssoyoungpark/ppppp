import React from 'react'
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const HeaderPage = () => {
    const [uid, setUid] = useState();

    const onLogout = () => {
        sessionStorage.removeItem('uid');
        setUid('')
    }

    useEffect(() => {
        setUid(sessionStorage.getItem('uid'));

    }, [uid]);
    return (
        <div>
            <Link to="/">Home</Link>
            <Link to="/board/list">게시판관리</Link>
            <Link to="/user">사용자관리</Link>
            {!uid ?
                <Link to="/login" style={{ float: 'right' }}>Login</Link>
                :
                <>
                    <span>{uname} ({uid})</span>
                    <a href="#" onClick={onLogout} style={{ float: 'right' }}>Logout</a>
                </>
            }
            <hr/>
        </div>
    )
}

export default HeaderPage