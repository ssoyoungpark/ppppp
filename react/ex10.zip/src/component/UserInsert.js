import React from 'react'

const UserInsert = () => {
  return (
    <div>UserInsert</div>
  )
}

export default UserInsert