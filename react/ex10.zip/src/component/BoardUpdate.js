import React, { useEffect, useState } from 'react'
import axios from 'axios';

const BoardUpdate = ({match, history}) => {
  const bno=match.params.bno;
  const [board, setBoard] = useState('');
  const {title, content} = board;
  
  const callAPI = async() => {
    const result = await axios.get(`/board/read/${bno}`);
    setBoard(result.data);
  }
  const onChangeForm = (e) => {
    setBoard({
      ...board,
      [e.target.name]: e.target.value
    })
  }

  const onSubmit = async() => {
    if(!window.confirm('Do you want to modify?')) return;
    await axios.post('/board/update', board);
    history.go(-2);
  }

  useEffect(()=>{
    callAPI();
  },[]);

  if(!board) return <h1>Loading......</h1>

  return (
    <div>
      <input 
        onChange={onChangeForm}
        value={title}
        name="title" 
        placeholder='Title' 
        size={80}/>
      <hr/>
      <textarea 
        onChange={onChangeForm}
        value={content}
        name="content" 
        placeholder='Content' 
        rows={10} 
        cols={80}/>
        <hr/>
        <button 
          onClick={onSubmit}
          className='grayButton'>Modify</button>
        <button className='grayButton'>Reset</button>
    </div>
  )
}

export default BoardUpdate