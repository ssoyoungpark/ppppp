import React, { useState } from 'react'
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Form from 'react-bootstrap/Form';
import Alert from 'react-bootstrap/Alert';
import axios from 'axios';
import HeaderPage from './HeaderPage';


const LoginPage = ({ history }) => {
    const [form, setForm] = useState({
        uid: '',
        upass: '',
        uname: ''
    });

    const { uid, upass, uname } = form;
    const [message, setMessage] = useState('Message.....');

    const onChange = () => {
        
        setForm({
            ...form,
            [e.target.name]: e.target.value
        })
    }
    const onSubmit = async (e) => {
        e.preventDefault();
        const result = await axios.get(`/user/read${uid}`);
        const user = result.data;
        if (!user) {
            setMessage('아이디가 존재하지 않습니다.');
        } else if (upass !== user.upass) {
            setMessage('비밀번호가 일치하지 않습니다.');

        } else {
            sessionStorage.setItem('uid', uid);
            history.push('/');
        }
    }

    return (
        <div>
            <HeaderPage/>
            <Card style={{ width: '28rem', margin: '0px auto', marginTop: '5rem' }}>
                <Card.Body>
                    <Card.Title>Login</Card.Title>
                    <Form>
                        <Form.Control
                            name="uid"
                            onChange={onChange}
                            value={uid}
                            className='my-3'
                            placeholder='User ID' />
                        <Form.Control
                            name="upass"
                            onChange={onChange}
                            value={upass}
                            className='my-3'
                            type="password"
                            placeholder='Password' />

                        <Button
                            onChange={onSubmit}
                            variant="primary"
                            style={{ width: '100%' }}>Login</Button>
                    </Form>
                </Card.Body>
                {message &&
                    <Alert className='my-3 text-center'>{message}</Alert>
                }
            </Card>
        </div>
    )
}

export default LoginPage