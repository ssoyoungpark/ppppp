import React from 'react'
import HeaderPage from './HeaderPage'

const HomePage = () => {
  return (
    
    <div>
      <HeaderPage/>
      HomePage
    </div>
  )
}

export default HomePage