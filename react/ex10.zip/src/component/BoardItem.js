import React from 'react'
import { Link } from 'react-router-dom';

const BoardItem = ({board}) => {
  const {bno, title, writer, regDate, uname, updateDate} = board;
  return (
    <tr>
      <td>{bno}</td>
      <td>
        <Link to={`/board/read/${bno}`}>{title}</Link></td>
      <td>{regDate}/<b>{updateDate}</b></td>
      <td>{uname} <b>{writer}</b></td>
    </tr>
  )
}

export default BoardItem