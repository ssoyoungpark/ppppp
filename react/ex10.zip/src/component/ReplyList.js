import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Form } from 'react-bootstrap';

const ReplyList = ({ bno }) => {
    const [list, setList] = useState([]);
    const [page, setPage] = useState(1);
    const [total, setTotal] = useState(0);
    const [last, setLast] = useState(1);
    const [content, setContent] = useState('');
    
    const onChange = (e) => {
        setData({
            ...data,
            content:e.target.value
        })
    }
    const num = 5;


    const callAPI = async () => {
        const result = await axios.get(`/reply/list/${bno}?page=${page}&num=${num}`);
        const newList = list.concat(result.data.list);
        setList(newList);
        setTotal(result.data.total);
        setLast(Math.ceil(result.data.total / num));
    }

    useEffect(() => {
        callAPI();
    }, [page]);

    const onSubmit = async (e) => {
        e.prventDefault();
        if (content === '') {
            alert('내용을 입력해 주세요!');
            return;
        }

        await axios.post('/reply/insert', data);
        setDate({
            bno: bno,
            replyer: sessionStorage.getItem('uid'),
            content: ''
        })
        setPage(1);

    }

    if (!list) return <h1>Loading.....</h1>

    return (
        <div>

            <Form onSubmit={onSubmit}>
                <Form.Control
                    value={contnt}
                    onChange={}
                    placeholder='내용을 입력하세요....' />
                <button type='submit'>등록</button>
            </Form>
            <hr />
            {list.map(reply =>
                <p key={reply.rno}>[{reply.rno}] {reply.content}</p>
            )}
            {page < last &&
                <button
                    onClick={() => setPage(page + 1)}
                    className='grayButton'>더보기 {page}/{last}
                </button>
            }
        </div>
    )
}

export default ReplyList