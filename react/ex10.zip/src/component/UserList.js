import React, { useEffect, useState } from 'react'
import { withRouter } from 'react-router-dom'
import UserList from './UserList'
import qs from 'qs';
import axios from 'axios';
import UserItem from './UserItem';
import Pagination from 'react-js-pagination';

import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Badge from 'react-bootstrap/Badge';
import Button from 'react-bootstrap/Button';


const UserPage = ({history, location}) => {
    const search=qs.parse(location.search, {ignoreQueryPrefix:true});
    const searchWord=!search.word ? '': search.word;
    const page=!search.page ? 1: parseInt(search.page);

    const [list, setList] = useState();
    const [total, setTotal] = useState(0);
    const [word, setWord] = useState(searchWord);

    const callAPI = async()=> {
        const result = await axios.get(`/user/list?word=${searchWord}&page=${page}`)
        setList(result.data.list);
        setTotal(result.data.total);
    }
    const onChangePage = (e) => {
        history.push(`/user/list?page=${e}&word=${searchWord}`);
    }
    const onKeyDown = (e) => {
        if(e.keyCode === 13){
            history.push(`/user/list?page=1&word=${e.target.value}`);
        }
    }

    useEffect(()=>{
        setWord(searchWord);
        callAPI();

    }, [location]);

    if(!list) return <h1>Loading...</h1>

  return (
    <div> 
        <Card className='my-3 p-2'>
            <Row>
                <Col md={4} xs={6}>
                    <Form.Control 
                    value={word}
                    onChange={(e)=>setWord(e.target.value)}
                    placeholder='검색어' 
                    onKeyDown={onKeyDown}/>
                </Col>
                <Col md={8} xs={6}>
                    <Button variant="primary">
                        Count <Badge bg="danger">{total}</Badge>
                    </Button>
                </Col>  
            </Row>
        </Card>
            
                {list.map(user=>
                    <UserItem key={user.uid} user={user}/>
                )}

        <Pagination
            activePage={page}
            itemsCountPerPage={5}
            totalItemsCount={total}
            pageRangeDisplayed={10}
            prevPageText={"‹"}
            nextPageText={"›"}
            onChange={onChangePage}/>
    </div>
  )
}

export default withRouter(UserList)