import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';

const BoardRead = ({ match, history }) => {
  const bno = match.params.bno;
  const [board, setBoard] = useState('');

  const callAPI = async () => {
    const result = await axios.get(`/board/read/${bno}`);
    setBoard(result.data);
  }

  const onClickDelete = async () => {
    if (!window.confirm('Do you want to delete?')) return;
    await axios.post('/board/delete/' + bno);
    history.go(-1);
  }

  useEffect(() => {
    callAPI();
  }, []);

  if (!board) return <h1>Loading......</h1>
  return (
    <div>
      <h3>[{bno}] {board.title}</h3>
      <h4>{board.uname} {board.writer}</h4>
      <h4>{board.regDate}/{board.updateDate}</h4>
      <hr />
      <p>{board.content}</p>
      {sessionStorage.getItem("uid") === board.writer &&
        <>
          <Link to={`/board/update/${bno}`}>
            <button className='grayButton'>수정</button>
          </Link>

          <button
            onClick={onClickDelete}
            className='grayButton'>삭제</button>
        </>
      }
      <button
        onClick={() => history.go(-1)}
        className='grayButton'>목록</button>
        <hr/>
        <ReplyList/>
    </div>
  )
}

export default BoardRead