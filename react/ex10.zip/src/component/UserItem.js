import React from 'react'
import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Image from 'react-bootstrap/Image'


const UserItem = ({user}) => {
    const {uid, uname, photo} = user;
    return (
        <Card className='my-3 p-2'>
            <Row>
                <Col lg={2}>
                    {!photo ?
                    <Image src="/a1.png" fluid={true} style={{width:100}}/>
                    :
                    <Image src={photo} fluid={true} style={{width:100}}/>
                    }
                </Col>
                <Col lg={10}>
                    <h4>{uid}</h4>
                    <h4>{uname}</h4>
                </Col>
            </Row>
        </Card>
    )
}

export default UserItem