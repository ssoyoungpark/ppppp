import React, { useEffect, useState } from 'react'
import User from './User';

const Users = () => {
    const [users, setUsers] = useState();
    const callAPI = () =>{
        fetch('https://jsonplaceholder.typicode.com/users')
        .then(response => response.json())
        .then(json =>{
            const newUser=users.filter(user=>user.id<=3);
            setUsers(newUser);
            
        });
    }

    useEffect(()=>{
        callAPI();
    },[]);

    if(!users){
        return(
        <h1>데이터를 불러오는 중입니다...</h1>
        );
    }

    return (
        <div>
            <h1>User List</h1>
            {users.map(user=><User key={user.id} user={user}/>)}
        </div>
    )
}

export default Users