import React, { useState } from 'react'
import Post from './Post';
import Todo from './Todo';

const User = (props) => {
    const {id, name, username, email, address, phone}=props.user;
    
    const [todos, setTodos] = useState();
    const [posts, setPosts] = useState();

    const [showTodos, setShowTodos] = useState(false);
    const [showPosts, setShowPosts] = useState(false);

    const callTodos = () => {
        fetch('https://jsonplaceholder.typicode.com/todos')
        .then(response => response.json())
        .then(json => {
            const newTodos=json.filter(todo=> todo.userId === id);
            setTodos(newTodos);
            setShowTodos(!showTodos);
        });
    }

    const callPosts = () => {
        fetch('https://jsonplaceholder.typicode.com/posts')
        .then(response => response.json())
        .then(json => {
            const newPosts=json.filter(post=> post.userId === id);
            setPosts(newPosts);
            setShowPosts(!showPosts);
        });
    }

    return (
        <div style={{textAlign:'left',width:500, margin:'0px auto', marginTop:30}}>
            <span>{id}</span>
            <span>{name}({email}-{username}</span>
            <div style={{borderBottom:'1px dotted gray',margin:'20px 0px'}}>
                {address.street}
                {address.suite}
                {address.city}
                <br/>
                <button onClick={callTodos}>Todo List</button>
                <button onClick={callPosts}>Post List</button>
                {showTodos &&
                    <div>
                        {todos && todos.map(todo=> <Todo key={todo.id} todo={todo}/>)}
                    </div>    
                }
                {showPosts &&
                    <div>
                        {posts && posts.map(post=> <Post key={post.id} post={post}/>)}
                    </div>    
                }
            </div>
        </div>
    )
}

export default User