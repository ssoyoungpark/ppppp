import React, { useEffect, useRef, useState } from 'react'
import Student from './Student';
import StudentInsert from './StudentInsert';

export const StudentList = () => {
    const refNo = useRef(4);

    const [data, setData] = useState([
        {id:1, sname:'홍길동', address:'인천 남구 학익동', tel:'010-1010-1010'},
        {id:2, sname:'심청이', address:'인천 서구 학익동', tel:'010-2020-2020'},
        {id:3, sname:'강감찬', address:'서울시 금천구 독산동', tel:'010-3030-3030'}
    ]);
    
    const onDelete = (id) => {
        if(!window.confirm(`${id}번 학생을 삭제하실래요??`)) return;
        const newData=data.filter(s => s.id !== id);
        setData(newData);
    }
    const onInsert = (s) =>{
        if(!window.confirm(`${refNo.current}번 학생을 등록하실래요??`)) return;
        const newData=data.concat({
            id: refNo.current,
            sname: s.sname,
            address: s.address,
            tel: s.tel
        });
        setData(newData);
        refNo.current=refNo.current+1;
    }

    return (
        <div>
            <StudentInsert onInsert={onInsert} no={refNo.current}/>
            <hr/>
            <table width={600}>
                {data.map(s=>
                    <Student key={s.id}
                    id={s.id}
                    sname={s.sname} 
                    address={s.address} 
                    tel={s.tel}
                    onDelete={onDelete}/>)
                }
            </table>
        </div>
    )
}
export default StudentList