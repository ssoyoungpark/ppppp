import React from 'react'

const Comment = (props) => {
    const {id, name, email, body} = props.comment;

    return (
        <div>
            <p style={{fontSize:12}}>{id} : {name}({email})</p>
            <p style={{fontSize:12}}>{body}</p>
        </div>
    )
}

export default Comment