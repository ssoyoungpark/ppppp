import React, { useEffect, useRef, useState } from 'react'

const Info = () => {
    const [name, setName] = useState('');
    const [nickname, setNickname] = useState('');
    const refNumber = useRef(0);

    useEffect(()=>{
        refNumber.current=refNumber.current+1;
        console.log('렌더링...' + refNumber.current);
        
        return ()=>{ //뒤정리함수 reRendering전에 실행
                console.log('Clean Up...', name)
            }
    })

    

    return (
        <div>
            <input value={name} onChange={(e)=>setName(e.target.value)} type="text" placeholder='이름'/>
            <input value={nickname} onChange={(e)=>setNickname(e.target.value)} type="text" placeholder='별명'/>
            <hr/>
            <h3>이름:{name}</h3>
            <h3>별명:{nickname}</h3>
        </div>
    )
}

export default Info