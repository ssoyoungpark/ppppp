import React, { useEffect, useRef, useState } from 'react'

const UseRefSample1 = () => {
    const refId = useRef();
    const [id, setId] = useState('');

    useEffect(()=>{
        console.log('렌더링....')
        refId.current.focus();
    },[]);

    const onClickLogin = () => {
        alert(`${refId.current.value}이 로그인하셨습니다.`);
        refId.current.value='';
        refId.current.focus();
    }

    const onKeyDownId = (e) => {
        if(e.key === 'Enter') onClickLogin();
    }
    return (
        <div>
            <input
                onKeyDown={onKeyDownId}
                ref={refId}
                type="text"
                placeholder='User Id'
            />
            <button onClick={onClickLogin}>로그인</button>
        </div>
    )
}

export default UseRefSample1