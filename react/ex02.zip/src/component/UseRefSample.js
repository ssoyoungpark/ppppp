import React, { useRef,useState } from 'react'

const UseRefSample = () => {
    const [count, setCount] = useState(0);
    const refCount = useRef(0);
    let varCount=0;

    console.log('렌더링...');
    console.log('refCount:', refCount.current);

    const onClickRef = () =>{
        refCount.current=refCount.current+1;
        console.log('refCount:' + refCount.current);
    }

    const onClickVar = () => {
        varCount=varCount+1;
        console.log('varCount:' + varCount);

    }
    return (
        <div>
            <p>State변수: {count}</p>
            <p>Ref변수: {refCount.current}</p>
            <p>Var변수: {varCount}</p>

            <button onClick={()=>setCount(count+1)}>
                State변수 증가
            </button>
            <button onClick={onClickRef}>
                Ref변수 증가
            </button>
            <button onClick={onClickVar}>
                Var변수 증가
            </button>
        </div>
    )
}

export default UseRefSample