import React, { useEffect, useRef, useState } from 'react'
import Post from './Post';

const Posts = () => {
    const {posts, setPosts} = useState();
    const [page, setPage] = useState(1);
    const last=useRef(1);

    const callAPI = () =>{
        fetch('https://jsonplaceholder.typicode.com/posts')
        .then(response => response.json())
        .then(json =>{
            //console.log(json);
            let start=(page-1)*10 + 1;
            let end=(page*10);
            last.current=Math.ceil(json.length/3);
            const newPosts=json.filter(post=>post.id>=start && post.id<=end);
            setPosts(newPosts);
        });
    }

    useEffect(()=>{
        callAPI();
    },[page]);

    if(!posts){
        return(
        <h1>데이터를 불러오는 중입니다...</h1>
        );
    }
    return (
        <div>
            <h1>Post List</h1>
            { posts.map(post=>
                <Post key={post.id} post={post}/>)
            }
        </div>
    )
}

export default Posts