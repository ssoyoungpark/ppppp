package model;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class CouDAO {
	
	//���µ��
	public void insert(CouVO vo) {
        try {
           String sql="insert into courses(lcode,lname,room,hours,instructor,capacity) values(?,?,?,?,?,?)";
           PreparedStatement ps=Database.CON.prepareStatement(sql);
           ps.setString(1, vo.getLcode());
           ps.setString(2, vo.getLname());
           ps.setString(3, vo.getRoom());
           ps.setInt(4, vo.getHours());
           ps.setString(5, vo.getInstructor());
           ps.setInt(6, vo.getCapacity());
           ps.execute();
           
        }catch(Exception e) {
           System.out.println("���µ��" + e.toString());
        }
        
     }
	
	 //���л� �ڵ�
    public String getCode() {
       String code="";
       try {
          String sql="select max(lcode) code from courses";
          PreparedStatement ps=Database.CON.prepareStatement(sql);
          ResultSet rs=ps.executeQuery();
          if(rs.next()) {
        	  String scode=rs.getString("code");
        	  scode=scode.substring(1);
        	  int icode=Integer.parseInt(scode)+1;
        	  code = "N" + icode;
          }
       }catch(Exception e) {
          System.out.println("�����ڵ�" + e.toString());
       }
       return code;
    }  
	
	//��������
	public CouVO read(String lcode) {
		CouVO vo=new CouVO();
		try {
			String sql="select * from cou where lcode=?";
			PreparedStatement ps=Database.CON.prepareStatement(sql);
			ps.setString(1, lcode);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				vo.setLcode(rs.getString("lcode"));
				vo.setLname(rs.getString("lname"));
				vo.setRoom(rs.getString("room"));
				vo.setCapacity(rs.getInt("capacity"));
				vo.setPersons(rs.getInt("persons"));
				vo.setHours(rs.getInt("hours"));
				vo.setInstructor(rs.getString("instructor"));
				vo.setPname(rs.getString("pname"));
				vo.setDept(rs.getString("dept"));
			}
		}catch(Exception e) {
			System.out.println("��������:" + e.toString());
		}
		return vo;
	}
	//���¸��
		public JSONObject list(SqlVO vo) {
			JSONObject object=new JSONObject();
			try {
				String sql="call list('cou',?,?,?,?,?,?)";
				CallableStatement cs=Database.CON.prepareCall(sql);
				cs.setString(1, vo.getKey());
				cs.setString(2, vo.getWord());
				cs.setString(3, vo.getOrder());
				cs.setString(4, vo.getDesc());
				cs.setInt(5, vo.getPage());
				cs.setInt(6, vo.getPer());
				cs.execute();
				
				ResultSet rs=cs.getResultSet();
				JSONArray jArray=new JSONArray();
				while(rs.next()) {
					JSONObject obj=new JSONObject();
					obj.put("lcode", rs.getString("lcode"));
					obj.put("lname", rs.getString("lname"));
					obj.put("hours", rs.getString("hours"));
					obj.put("room", rs.getString("room"));
					obj.put("instructor", rs.getString("instructor"));
					obj.put("capacity",  rs.getInt("capacity"));
		            obj.put("persons",  rs.getInt("persons"));
		            obj.put("pname", rs.getString("pname"));
		            obj.put("dept", rs.getString("dept"));
					jArray.add(obj);
				}
				object.put("array", jArray);
				
				cs.getMoreResults();
				
				rs=cs.getResultSet();
				int total=0;
				if(rs.next()) total=rs.getInt("total");
				object.put("total", total);
				
				int last=total%vo.getPer()==0 ? total/vo.getPer():
					total/vo.getPer()+1;
				object.put("last", last);
			}catch(Exception e) {
				System.out.println("���¸��:" + e.toString());
			}
			return object;
		}
}
