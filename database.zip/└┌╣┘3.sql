DROP TABLE tbl_score;
DROP TABLE tbl_type;
DROP TABLE tbl_student;
DROP TABLE tbl_dept;

create table tbl_dept(
  dcode char(3) not null PRIMARY key,
  dname VARCHAR(100) not null
);
desc tbl_dept;

create table tbl_type(
  tcode char(3) not null PRIMARY key,
  tname VARCHAR(100) not null
);

create table tbl_student(
  sno char(3) not null PRIMARY key,
  sname VARCHAR(20) not null,
  dcode char(3),
  FOREIGN key(dcode) REFERENCES tbl_dept(dcode)
);

create table tbl_score(
  sno char(3) not null,
  tcode char(3) not null,
  sdate date DEFAULT sysdate,
  grade int DEFAULT 0,
  PRIMARY key(sno, tcode),
  FOREIGN key(sno) REFERENCES tbl_student(sno),
  FOREIGN key(tcode) REFERENCES tbl_type(tcode)
);


insert into tbl_dept(dcode, dname)
values('D10', '��ǻ����������');
insert into tbl_dept(dcode, dname)
values('D20', '�������ڰ���');
insert into tbl_dept(dcode, dname)
values('D30', '�濵��');


insert into tbl_student(sno,sname, dcode)
values('100', 'ȫ�浿', 'D10');
insert into tbl_student(sno,sname, dcode)
values('200', '��û��', 'D20');
insert into tbl_student(sno,sname, dcode)
values('300', '������', 'D10');


insert into tbl_type
values('T10', '�߰�');
insert into tbl_type
values('T20', '�⸻');
insert into tbl_type
values('T30', '9������');


insert into tbl_score(sno, tcode, sdate, grade)
values('100', 'T10', '2020-03-23', 99);
insert into tbl_score(sno, tcode, sdate, grade)
values('200', 'T10', '2020-03-23', 88);
insert into tbl_score(sno, tcode, sdate, grade)
values('300', 'T10', '2020-03-23', 100);
insert into tbl_score(sno, tcode, sdate, grade)
values('100', 'T20', '2020-06-30', 85);
insert into tbl_score(sno, tcode, sdate, grade)
values('200', 'T20', '2020-06-30', 76);
insert into tbl_score(sno, tcode, sdate, grade)
values('300', 'T30', '2020-09-25', 69);


select * from tbl_score;
/* tbl_score <-�� ���� */
delete from tbl_score;



/*����*/
update tbl_score set tdate='2020-03-23'
where sno='100' and tcode='T10';



select * 
  from tbl_student s,tbl_dept d
  where s.dcode=d.dcode;

select s. *, dname 
  from tbl_student s,tbl_dept d
  where s.dcode=d.dcode;

/*�й�, �л���, �����ڵ�, �����ڵ��, ������, ����*/
create view view_score as
(select g.*, s.sname, t.tname, d.dname
from tbl_score g, tbl_student s, tbl_type t, tbl_dept d
where g.sno=s.sno and g.tcode=t.tcode and s.dcode=d.dcode);

select * from view_score order by sname;

commit;
select * from tbl_dept;
select max(dcode) mcode from tbl_dept;



/*����*/
update tbl_dept set dname='��ǻ���������а�'
where dcode='D10';

update tbl_dept set dname='�������ڰ��а�'
where dcode='D20';
update tbl_dept set dname='�������ڰ��а�' where dcode='D20';


select * from tbl_type;
select max(tcode) from tbl_type;

