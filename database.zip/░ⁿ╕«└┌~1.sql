select * from dba_users;
drop user java;