drop table tbl_score;
drop table tbl_type;
drop table tbl_student;