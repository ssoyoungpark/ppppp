create table tbl_camp(
  code char(4) not null PRIMARY key,
  cname VARCHAR(200) not null,
  address VARCHAR(500) not null
);
drop table tbl_camp;

create table tbl_facility(
  fcode char(3) not null PRIMARY key,
  fname VARCHAR(20) not null
);

create table tbl_type(
  tcode char(3) not null primary key,
  tname VARCHAR(20) not null
);

create table tbl_camp_facility(
  code char(4) not null,
  fcode char(3) not null,
  PRIMARY key(code, fcode),
  FOREIGN key(code) REFERENCES tbl_camp(code),
  FOREIGN key(fcode) REFERENCES tbl_facility(fcode)
);

create table tbl_camp_type(
  code char(4) not null,
  tcode char(3) not null,
  qnt int default 0,
  PRIMARY key(code, tcode),
  FOREIGN key(code) REFERENCES tbl_camp(code),
  FOREIGN key(tcode) REFERENCES tbl_type(tcode)
);


insert into tbl_camp
values('c100','���丮','������');
insert into tbl_camp
values('c200','�ֹ�','��õ');
insert into tbl_camp
values('c300','�ڿ�','��⵵');
select * from tbl_camp;


insert into tbl_facility
values('f10','����');
insert into tbl_facility
values('f20','����');
insert into tbl_facility
values('f30','ȭ���');
insert into tbl_facility
values('f40','��������');
select * from tbl_facility;


insert into tbl_type
values('t10','����ķ��');
insert into tbl_type
values('t20','�۷���');
insert into tbl_type
values('t30','ī���');
select * from tbl_type;

insert into tbl_camp_facility
values('c100','f10');
insert into tbl_camp_facility
values('c100','f20');
insert into tbl_camp_facility
values('c100','f30');
insert into tbl_camp_facility
values('c200','f10');
insert into tbl_camp_facility
values('c200','f20');
insert into tbl_camp_facility
values('c300','f30');
insert into tbl_camp_facility
values('c300','f40');
select * from tbl_camp_facility;


insert into tbl_camp_type
values('c100','t10',5);
insert into tbl_camp_type
values('c100','t20',10);
insert into tbl_camp_type
values('c200','t10',12);
insert into tbl_camp_type
values('c200','t20',5);
insert into tbl_camp_type
values('c200','t30',20);
insert into tbl_camp_type
values('c300','t10',22);
insert into tbl_camp_type
values('c300','t30',10);
select * from tbl_camp_type;
COMMIT;

create view view_facility as
(select c.*, fname
from tbl_facility f, tbl_camp_facility c
where c.fcode=f.fcode);

create view view_type as
(select c.*, tname
from tbl_camp_type c, tbl_type t
where c.tcode=t.tcode);
select * from view_type;
COMMIT;


select * from tbl_camp;
select * from view_facility where code='c100';
select * from view_type where code='c100';

select * from view_facility;

select max(fcode) mcode from tbl_facility;








